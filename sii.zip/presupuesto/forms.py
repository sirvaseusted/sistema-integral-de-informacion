#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django.forms import *
from django import forms
from presupuesto.models import *

#áéíóú
class Formulario_Orden_Servicio_Unidad(ModelForm):
	class Meta:
		model = Orden_Servicio_Unidad
		exclude = ('unidad',)
		widgets = {
			'numero': TextInput(attrs={'class' :'form-control','placeholder': 'Número de la Orden de Servicio','required':'true'}),
			'tipo_servicio': Select(attrs={'class' :'select2','placeholder': 'Tipo','required':'true'}),
			'importe': TextInput(attrs={'class' :'form-control','placeholder': 'Cantidad','required':'true'}),
			'descripcion': Textarea(attrs={'class' :'form-control','placeholder': 'Descripción del Servicio Solicitado','required':'true'}),
			}