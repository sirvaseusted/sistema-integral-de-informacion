from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from galeria.models import *
from mensajes.models import *
from unidad.views import *
from carpeta.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from carpeta.forms import  *
from django.db.models import Sum
from django.db.models import Count

# Create your views here.
# Aqui comienzan las vistas relacionadas con los documentos de la unidad
@login_required(login_url='/ingresar')
def documentos(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	#documentos oficiales solicitados
	document = Ficheros.objects.filter(unidad=request.session['unidad'])
	#documentos oficiales subidos por el usuario
	fichero = Documentos.objects.filter(documento=document, unidad =request.session['unidad'])
	files = []
	for file in fichero: 
		files.append(file.documento)
	unidad= Unidad.objects.get(id=id_unidad)

	unidades= Unidad.objects.annotate(cantidad_documentos=Count('documentos__unidad')).filter(subordinacion=request.session['unidad']).order_by('-municipio')


	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	for unidad1 in unidades: 
		for perfil1 in perfiles: 
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad1.id]=unidad1.id
	return render_to_response('documento/documentos.html',{
	'document':document, 
	'fichero':fichero, 
	'files':files,
	'id_unidad':id_unidad,
	'unidades':unidades,
	'perfil':perfil,
	'unidad':unidad 
	}, context_instance=RequestContext(request))
	
@login_required(login_url='/ingresar')
def docsubordinados(request):

	id_unidad = request.GET.get('id')
	unidad= Unidad.objects.get(id=id_unidad)
	#documentos oficiales solicitados
	document = Ficheros.objects.filter(unidad=request.session['unidad'])
	#documentos oficiales subidos por el usuario
	fichero = Documentos.objects.filter(documento=document, unidad = id_unidad)
	files = []
	for file in fichero: 
		files.append(file.documento)

	return render_to_response('documento/documentos_subordinados.html',{
	'document':document, 
	'fichero':fichero, 
	'files':files,
	'id_unidad':id_unidad,
	'unidad':unidad 
	}, context_instance=RequestContext(request))

	
@login_required(login_url='/ingresar')
def form_documentos(request):
	id_documento = request.GET.get('id_doc')
	id_unidad = request.GET.get('id_unidad')
	unidad = Unidad.objects.get(id = id_unidad)
	document = Ficheros.objects.get(id=id_documento)
	
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_documento = Formulario_Documentos(request.POST, request.FILES)
		if form_documento.is_valid():
			form = form_documento.save(commit=False)
			form.unidad=unidad
			form.documento=document
			
			form.save()
			acciones='El Documento '+ str(form.documento) + " fue agregado a la unidad "+ str(form.unidad)
			registrar_log(request,acciones,2)
			if str(form.unidad.id) == str(request.session['unidad']):
				return HttpResponseRedirect('/documentos')
			else:
				return HttpResponseRedirect('/docsubordinados?id='+id_unidad)
	else:
		form_documento = Formulario_Documentos()
	return render_to_response('documento/formulario.documento.html',{'form_documento':form_documento, 'unidad':unidad, 'document':document} , context_instance=RequestContext(request))

#editando documento	
@login_required(login_url='/ingresar')
def form_editar_doc(request):
	id_unidad = request.session['unidad']
	unidad=Unidad.objects.get(id=id_unidad)
	# me quede por aki... arreglar esto
	id_fichero = request.GET.get('id_doc')
	fichero=Documentos.objects.get(id=id_fichero)
	#fichero.delete()
	document = Ficheros.objects.filter(unidad=request.session['unidad'])
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_fichero = Formulario_Documentos(request.POST, request.FILES,instance=fichero)
		if form_fichero.is_valid():
			
			form = form_fichero.save(commit=False)
			form.unidad=unidad
			
			form.save()
			acciones='El Documento '+ form.documento.nombre + " fue agregado a la unidad "+ form.unidad.nombre + "de" + form.unidad.municipio.municipio
			registrar_log(request,acciones,4)
			return HttpResponseRedirect('/documentos')
	else:
		form_fichero = Formulario_Documentos(instance=fichero)
	return render_to_response('documento/editar_documento.html', {'form_fichero':form_fichero, 'unidad':unidad, 'document':document,'fichero':fichero}, context_instance=RequestContext(request))
	
#aqui acaban las vistas relacionadas con los documentos de la unidad
#//////////////////////////////////////////////////////////////////////////////////////////////
#Aqui comienzan las vistas sobre la conectividad de la unidad


@login_required(login_url='/ingresar')
def conectividad(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil2={}
	for unidad1 in unidades: 
		for perfil1 in perfiles: 
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil2[unidad1.id]=unidad1.id
	unidades_sub= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	
#objeto conectividad
	conectividad1 = Conectividad.objects.filter(unidad=request.session['unidad'])
	conectividadd = conectividad1
	if conectividad1:
		conectividadd = conectividad1[0]

#Tomando objeto enlace
	enlace = Enlaces.objects.filter(conectividad=conectividadd)
#Tomando Paginas web
	webs = P_web.objects.filter(conectividad=conectividadd)
	if request.method=='POST':
		if request.POST['tipo']=='seleccionar':
			select = request.POST['select2']
			unidad_select = Unidad.objects.get(id = select)
			#objeto conectividad
			conectividad1 = Conectividad.objects.filter(unidad=unidad_select)
			conectividadd = conectividad1
			if conectividad1:
				conectividadd = conectividad1[0]
			#Tomando objeto enlace
			enlace = Enlaces.objects.filter(conectividad=conectividadd)
			#Tomando Paginas web
			webs = P_web.objects.filter(conectividad=conectividadd)
			return render_to_response('conectividad/conectividad.html',
			{'id_unidad':id_unidad,
			'conectividadd':conectividadd,
			'unidad':unidad,
			'enlace':enlace,
			'webs':webs,
			'unidades_sub':unidades_sub,
			'unidad_select':unidad_select,
			'perfil2':perfil2,
			},
			context_instance=RequestContext(request))
		form_conectividad = Formulario_Conectividad(request.POST)
		if form_conectividad.is_valid():
			if request.POST['tipo']=='reg_conn_unidad':
				unidad= Unidad.objects.get(id=request.POST['unidadselec'])
			form = form_conectividad.save(commit=False)
			form.unidad = unidad
			
			form.save()
			acciones='Se agregaron '+ str(form.cant_cuentas) + " a la unidad "+ form.unidad.nombre + "de" + form.unidad.municipio.municipio
			registrar_log(request,acciones,2)
			return HttpResponseRedirect('/conectividad')
	else:
		form_conectividad = Formulario_Conectividad()
	
	return render_to_response('conectividad/conectividad.html',{
	'conectividadd':conectividadd,
	'id_unidad':id_unidad,
	'unidad':unidad,
	'enlace':enlace,
	'webs':webs,
	'unidades_sub':unidades_sub,
	'form_conectividad':form_conectividad,	}, context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def formulario_editar_conectividad(request):
	id_unidad=request.GET.get('id')
	unidad= Unidad.objects.get(id=id_unidad)
	
	# cogiendo la conn

	conn=Conectividad.objects.get(unidad=unidad)
	
	
	
	#fichero.delete()
	
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_conn = Formulario_Conectividad(request.POST,instance=conn)
		if form_conn.is_valid():
			
			form = form_conn.save(commit=False)
			form.unidad = unidad
				
			form.save()
			
			acciones='Actualizaron '+ str(form.cant_cuentas) + " cuentas a la unidad "+ form.unidad.nombre + "de" + form.unidad.municipio.municipio
			registrar_log(request,acciones,4)
			return HttpResponseRedirect('/conectividad')
	else:
		form_conn = Formulario_Conectividad(instance=conn)
	return render_to_response('conectividad/editar_conectividad.html', {'form_conn':form_conn, 'unidad':unidad, 'conn':conn}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def formulario_enlace(request):
	id_unidad = request.GET.get('id')
	unidad=Unidad.objects.get(id=id_unidad)
	conectividadd = Conectividad.objects.get(unidad=unidad)
	ancho_banda = Ancho_banda.objects.all()
	
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_enlace = Formulario_Enlace(request.POST)
		if form_enlace.is_valid():
			form = form_enlace.save(commit=False)
			form.ip = request.META['REMOTE_ADDR']
			form.conectividad = conectividadd
			form.save()
			acciones='El enlace '+ form.tipo + " fue agregado a la unidad "+ unidad.nombre +" de" + unidad.municipio.municipio
			registrar_log(request,acciones,2)
			return HttpResponseRedirect('/conectividad')
	else:
		form_enlace = Formulario_Enlace()
	return render_to_response('conectividad/formulario_enlace.html',{'form_enlace':form_enlace, 'unidad':unidad, 'ancho_banda':ancho_banda} , context_instance=RequestContext(request))


	
@login_required(login_url='/ingresar')
def formulario_web(request):
	id_unidad = request.GET.get('id')
	unidad=Unidad.objects.get(id=id_unidad)
	conectividadd = Conectividad.objects.get(unidad=unidad)
	tipo_web = Tipo_web.objects.all()
	
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_web = Formulario_Web(request.POST)
		if form_web.is_valid():
			form = form_web.save(commit=False)
			form.conectividad = conectividadd
			form.save()
			acciones='La url '+ form.direccion + " fue agregada a la unidad "+ unidad.nombre +" de" + unidad.municipio.municipio
			registrar_log(request,acciones,2)
			return HttpResponseRedirect('/conectividad')
	else:
		form_web = Formulario_Web()
	return render_to_response('conectividad/formulario_web.html',{'form_web':form_web, 'unidad':unidad, 'tipo_web':tipo_web} , context_instance=RequestContext(request))

	
@login_required(login_url='/ingresar')
def info_enlace(request):
	id_enlace = request.GET.get('id')
	enlace=Enlaces.objects.get(id=id_enlace)
	permiso=comprobar_perfil(request,enlace.conectividad.unidad.id)
	if permiso ==2:
		return HttpResponseRedirect('/')
	editar=comprobar_perfil(request,enlace.conectividad.unidad.id)
	return render_to_response('conectividad/info_enlace.html',{'entity':enlace,'editar':permiso} , context_instance=RequestContext(request))
	
@login_required(login_url='/ingresar')
def info_web(request):
	id_web = request.GET.get('id')
	web = P_web.objects.get(id=id_web)
	permiso=comprobar_perfil(request,web.conectividad.unidad.id)
	if permiso ==2:
		return HttpResponseRedirect('/')
	editar=comprobar_perfil(request,web.conectividad.unidad.id)
	return render_to_response('conectividad/info_web.html',{'entity':web,'editar':permiso} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')	
def editar_enlace(request):
	id_enlace = request.GET.get('id')
	enlace = Enlaces.objects.get(id=id_enlace)
	conectividadd = Conectividad.objects.get(unidad=enlace.conectividad.unidad)
	ancho_banda = Ancho_banda.objects.all()
	# me quede por aki... arreglar esto
	
	
	#fichero.delete()
	
	permiso=comprobar_perfil(request,enlace.conectividad.unidad.id)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_enlace = Formulario_Enlace(request.POST,instance=enlace)
		if form_enlace.is_valid():
			
			form = form_enlace.save(commit=False)
			form.ip = request.META['REMOTE_ADDR']
			form.conectividad = conectividadd
			
			form.save()
			acciones='El enlace '+ enlace.tipo + " de la unidad "+ enlace.conectividad.unidad.nombre +" de" + enlace.conectividad.unidad.municipio.municipio + "fue editado"
			registrar_log(request,acciones,4)
			return HttpResponseRedirect('/conectividad')
	else:
		form_enlace = Formulario_Enlace(instance=enlace)
	return render_to_response('conectividad/editar_enlace.html', {'form_enlace':form_enlace, 'enlace':enlace, 'ancho_banda':ancho_banda}, context_instance=RequestContext(request))
	

@login_required(login_url='/ingresar')	
def editar_web(request):
	id_web = request.GET.get('id')
	web = P_web.objects.get(id=id_web)
	conectividadd = Conectividad.objects.get(unidad=web.conectividad.unidad)
	tipo_web = Tipo_web.objects.all()
	# me quede por aki... arreglar esto
	
	
	#fichero.delete()
	
	permiso=comprobar_perfil(request,web.conectividad.unidad.id)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_web = Formulario_Web(request.POST,instance=web)
		if form_web.is_valid():
			
			form = form_web.save(commit=False)
			form.conectividad = conectividadd
			
			form.save()
			acciones='La url '+ web.direccion + " de la unidad "+ web.conectividad.unidad.nombre +" de" + web.conectividad.unidad.municipio.municipio + "fue editada"
			registrar_log(request,acciones,4)
			return HttpResponseRedirect('/conectividad')
	else:
		form_web = Formulario_Web(instance=web)
	return render_to_response('conectividad/editar_web.html', {'form_web':form_web, 'web':web, 'tipo_web':tipo_web}, context_instance=RequestContext(request))

	
@login_required(login_url='/ingresar')
def borrar_enlace(request):
	id_enlace = request.GET.get('id')
	enlace = Enlaces.objects.get(id=id_enlace)
	permiso=comprobar_perfil(request,enlace.conectividad.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	
	enlace.delete()
	
	
	acciones='El enlace '+ enlace.tipo + " de la Unidad "+ enlace.conectividad.unidad.nombre+ " fue eliminado"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('/conectividad')


@login_required(login_url='/ingresar')
def borrar_web(request):
	id_web = request.GET.get('id')
	web = P_web.objects.get(id=id_web)
	permiso=comprobar_perfil(request,web.conectividad.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	
	web.delete()
	
	
	acciones='La web '+ web.direccion + " de la Unidad "+ web.conectividad.unidad.nombre+ " fue eliminado"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('/conectividad')


@login_required(login_url='/ingresar')
def aplicaciones(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	sin_aplicaciones = Aplicaciones.objects.exclude(unidad = id_unidad).exclude(estado= False)
	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil2={}
	for unidad1 in unidades: 
		for perfil1 in perfiles: 
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil2[unidad1.id]=unidad1.id
	#tomando trabajadores de unidades subordinadas
	
	unidades_sub= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	
	
	
#Tomando objeto aplicaciones
	aplicaciones = Aplicaciones.objects.filter(unidad=unidad)
	id_usuario=request.session['userid']
	perfil = Perfil.objects.get(user_id=id_usuario)
	
	if perfil.user.is_staff:
		solicitadas = Aplicaciones.objects.exclude(estado= True)
	else:
		solicitadas = []
#si me dan los datos por el post
	if request.method=='POST':
	#si lo que viene es una unidad
		if request.POST['select2']:
			select = request.POST['select2']
			unidad_select = Unidad.objects.get(id = select)
			sin_aplicaciones = Aplicaciones.objects.exclude(unidad = unidad_select.id).exclude(estado= False)
			
			seleccionado = Aplicaciones.objects.filter(unidad=unidad_select.id)
			
			return render_to_response('aplicaciones/aplicaciones.html',
			{'id_unidad':id_unidad,
			'unidad':unidad,
			'sin_aplicaciones':sin_aplicaciones,
			
			'unidades_sub':unidades_sub,
			'unidad_select':unidad_select,
			'seleccionado':seleccionado,
			'perfil2':perfil2,
			},
			context_instance=RequestContext(request))
	
	#si lo que viene es una aplicacion
		if request.POST['habilidad']:
			vista = request.POST['habilidad']
			if request.POST['unidadd']:
				unidad1 = request.POST['unidadd']
				print unidad
				otra_aplicacion = Aplicaciones.objects.get(id = vista)
				otra_aplicacion.unidad.add(unidad1)
				otra_aplicacion.save()
			else:
				otra_aplicacion = Aplicaciones.objects.get(id = vista)
				otra_aplicacion.unidad.add(unidad)
				otra_aplicacion.save()
			return render_to_response('aplicaciones/aplicaciones.html',
			{'aplicaciones':aplicaciones,
			'id_unidad':id_unidad,
			'unidad':unidad,
			'sin_aplicaciones':sin_aplicaciones,
			'solicitadas':solicitadas,
			'unidades_sub':unidades_sub,
			'perfil2':perfil2,},
			context_instance=RequestContext(request))
		
			
	if request.method=='GET':
		# capturo por get el id para eliminar una aplicacion
		id_aplicacion=request.GET.get('id')
		#aqui capturo el id para aprobarla
		id_aprobado=request.GET.get('aprobar')
		#aqui capturo el id para purgarla
		id_purgado=request.GET.get('purgar')
		
		if request.GET.get('id_unidad_select'):
			id_unidad_select = request.GET.get('id_unidad_select')
			otra_aplicacion = Aplicaciones.objects.filter(id = id_aplicacion, unidad = id_unidad_select)
			unidad1 = Unidad.objects.get(id = id_unidad_select)
			if otra_aplicacion:
				otra_aplicacion[0].unidad.remove(unidad1)
				otra_aplicacion[0].save()
				acciones='La aplicacion '+ str(otra_aplicacion[0].nombre) + " de la Unidad "+ unidad1.nombre + " de " + unidad1.municipio.municipio + " fue eliminada"
				registrar_log(request,acciones,3)
		else:
			otra_aplicacion = Aplicaciones.objects.filter(id = id_aplicacion, unidad = unidad)
			if otra_aplicacion:
				otra_aplicacion[0].unidad.remove(unidad)
				otra_aplicacion[0].save()
				acciones='La aplicacion '+ str(otra_aplicacion[0].nombre) + " de la Unidad "+ unidad.nombre + " de " + unidad.municipio.municipio + " fue eliminada"
				registrar_log(request,acciones,3)
		aprobado = Aplicaciones.objects.filter(id = id_aprobado)
		
		
		purgado = Aplicaciones.objects.filter(id = id_purgado)
		
		if aprobado:
			aprobado[0].estado = True
			aprobado[0].save()
			acciones='La aplicacion '+ str(aprobado[0].nombre) + " de la Unidad "+ str(aprobado[0].unidad.all()) + " editada"
			registrar_log(request,acciones,2)
		if purgado:
			purgado[0].delete()
						
		return render_to_response('aplicaciones/aplicaciones.html',
		{'aplicaciones':aplicaciones,
		'id_unidad':id_unidad,
		'unidad':unidad,
		'sin_aplicaciones':sin_aplicaciones,
		'solicitadas':solicitadas,
		'unidades_sub':unidades_sub,
		'perfil2':perfil2,},
		context_instance=RequestContext(request))
	
	return render_to_response('aplicaciones/aplicaciones.html',
	{'aplicaciones':aplicaciones,
	'id_unidad':id_unidad,
	'unidad':unidad,
	'sin_aplicaciones':sin_aplicaciones,
	'solicitadas':solicitadas,
	'unidades_sub':unidades_sub,
	'perfil2':perfil2,}, 
	context_instance=RequestContext(request))
		
	

@login_required(login_url='/ingresar')
def form_aplicacion(request):
	id_unidad = request.GET.get('unidad')
	unidad=Unidad.objects.get(id=id_unidad)
			
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_aplicacion = Formulario_Aplicacion(request.POST, request.FILES)
		if form_aplicacion.is_valid():
					
			form = form_aplicacion.save(commit=False)
			form.estado = False
			#form.unidad = id_unidad
			form.save()
			form_aplicacion.save_m2m()
			acciones='La aplicacion '+ form.nombre + " fue agregada a la unidad "+ form.unidad.nombre + " de "+form.unidad.municipio.municipio
			registrar_log(request,acciones,2)
			#joe = Author.objects.create(name="Joe")
			return HttpResponseRedirect('/aplicaciones')
	else:
		form_aplicacion = Formulario_Aplicacion()
	return render_to_response('aplicaciones/formulario_aplicacion.html',{'form_aplicacion':form_aplicacion, 'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def form_editar_app(request):
	id_unidad=request.session['unidad']
	unidad1= Unidad.objects.get(id=id_unidad)
	
	# cogiendo la app
	id_app = request.GET.get('id')
	app=Aplicaciones.objects.get(id=id_app)
	
	unidad2 = app.unidad.all()[:1]
	unidad = unidad2[0]
	
	#fichero.delete()
	
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_app = Formulario_Aplicacion(request.POST, request.FILES,instance=app)
		if form_app.is_valid():
			
			form = form_app.save(commit=False)
			form.estado = False
				
			form.save()
			form_app.save_m2m()
			acciones='La aplicacion '+ form.nombre + " de la unidad "+ unidad.nombre + " de "+unidad.municipio.municipio + "fue editada"
			registrar_log(request,acciones,4)
			return HttpResponseRedirect('/aplicaciones')
	else:
		form_app = Formulario_Aplicacion(instance=app)
	return render_to_response('aplicaciones/editar_aplicacion.html', {'form_aplicacion':form_aplicacion, 'unidad':unidad, 'app':app}, context_instance=RequestContext(request))
