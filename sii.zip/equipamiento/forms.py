from django.forms import *
from django import forms
from equipamiento.models import *



class Formulario_nom_tipo_pc(ModelForm):
	class Meta:
		model = nom_tipo_pc

class Formulario_so(ModelForm):
	class Meta:
		model = so
		widgets = {
			'so': TextInput(attrs={'class' :'form-control'}),
}
class Formulario_estado(ModelForm):
	class Meta:
		model = estado

class Formulario_pc(ModelForm):
	class Meta:
		model = pc
		exclude=('id_estado',)
		widgets = {
			'nombre': TextInput(attrs={'class' :'form-control'}),
			'responsable': Select(attrs={'class' :'select2',}),
			'so': Select(attrs={'class' :'select2'}),
			'tipo_pc': Select(attrs={'class' :'select2'}),
			}



class Formulario_nom_board_marca(ModelForm):
	class Meta:
		model = nom_board_marca

class Formulario_nom_socket(ModelForm):
	class Meta:
		model = nom_socket

class Formulario_board_pc(ModelForm):
	class Meta:
		model = board_pc
		exclude=('pc',)
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'board_socket': Select(attrs={'class' :'select2',}),
			'board_marca': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_procesador_marca(ModelForm):
	class Meta:
		model = nom_procesador_marca

class Formulario_nom_procesador_velocidad(ModelForm):
	class Meta:
		model = nom_procesador_velocidad

class Formulario_procesador(ModelForm):
	class Meta:
		model = procesador
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'procesador_socket': Select(attrs={'class' :'select2',}),
			'procesador_marca': Select(attrs={'class' :'select2'}),
			'procesador_velocidad': Select(attrs={'class' :'select2'}),
			}




class Formulario_nom_ram_marca(ModelForm):
	class Meta:
		model = nom_ram_marca

class Formulario_nom_ram_tipo(ModelForm):
	class Meta:
		model = nom_ram_tipo

class Formulario_nom_ram_velocidad(ModelForm):
	class Meta:
		model = nom_ram_velocidad

class Formulario_ram(ModelForm):
	class Meta:
		model = ram
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'ram_tipo': Select(attrs={'class' :'select2',}),
			'ram_marca': Select(attrs={'class' :'select2'}),
			'ram_velocidad': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_hdd_marca(ModelForm):
	class Meta:
		model = nom_hdd_marca

class Formulario_nom_hdd_tipo(ModelForm):
	class Meta:
		model = nom_hdd_tipo

class Formulario_nom_hdd_capacidad(ModelForm):
	class Meta:
		model = nom_hdd_capacidad

class Formulario_hdd(ModelForm):
	class Meta:
		model = hdd
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'hdd_tipo': Select(attrs={'class' :'select2',}),
			'hdd_marca': Select(attrs={'class' :'select2'}),
			'hdd_capacidad': Select(attrs={'class' :'select2'}),
			}

class Formulario_nom_cddvd_marca(ModelForm):
	class Meta:
		model = nom_cddvd_marca

class Formulario_nom_cddvd_tipo(ModelForm):
	class Meta:
		model = nom_cddvd_tipo

class Formulario_nom_cddvd_utilidad(ModelForm):
	class Meta:
		model = nom_cddvd_utilidad

class Formulario_cddvd(ModelForm):
	class Meta:
		model = cddvd
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'cddvd_tipo': Select(attrs={'class' :'select2',}),
			'cddvd_marca': Select(attrs={'class' :'select2'}),
			'cddvd_utilidad': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_fuente_marca(ModelForm):
	class Meta:
		model = nom_fuente_marca

class Formulario_nom_fuente_tipo(ModelForm):
	class Meta:
		model = nom_fuente_tipo

class Formulario_fuente(ModelForm):
	class Meta:
		model = fuente
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'potencia': TextInput(attrs={'class' :'form-control'}),
			'fuente_tipo': Select(attrs={'class' :'select2',}),
			'fuente_marca': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_tvideo_marca(ModelForm):
	class Meta:
		model = nom_tvideo_marca

class Formulario_nom_tvideo_tipo(ModelForm):
	class Meta:
		model = nom_tvideo_tipo

class Formulario_tvideo(ModelForm):
	class Meta:
		model = tvideo
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'capacidad': TextInput(attrs={'class' :'form-control'}),
			'ftvideo_tipo': Select(attrs={'class' :'select2',}),
			'tvideo_marca': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_tsonido_marca(ModelForm):
	class Meta:
		model = nom_tsonido_marca

class Formulario_nom_tsonido_tipo(ModelForm):
	class Meta:
		model = nom_tsonido_tipo

class Formulario_tsonido(ModelForm):
	class Meta:
		model = tsonido
		exclude=('pc', 'activo', 'capacidad')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'tsonido_tipo': Select(attrs={'class' :'select2',}),
			'tsonido_marca': Select(attrs={'class' :'select2'}),
			}



class Formulario_nom_tred_marca(ModelForm):
	class Meta:
		model = nom_tred_marca

class Formulario_nom_tred_tipo(ModelForm):
	class Meta:
		model = nom_tred_tipo

class Formulario_nom_tred_velocidad(ModelForm):
	class Meta:
		model = nom_tred_velocidad

class Formulario_tred(ModelForm):
	class Meta:
		model = tred
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'tred_tipo': Select(attrs={'class' :'select2',}),
			'tred_marca': Select(attrs={'class' :'select2'}),
			'tred_velocidad': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_chasis_marca(ModelForm):
	class Meta:
		model = nom_chasis_marca

class Formulario_nom_chasis_tipo(ModelForm):
	class Meta:
		model = nom_chasis_tipo

class Formulario_chasis(ModelForm):
	class Meta:
		model = chasis
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'chasis_tipo': Select(attrs={'class' :'select2',}),
			'chasis_marca': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_modem_marca(ModelForm):
	class Meta:
		model = nom_modem_marca

class Formulario_nom_modem_tipo(ModelForm):
	class Meta:
		model = nom_modem_tipo

class Formulario_modem(ModelForm):
	class Meta:
		model = modem
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'modem_tipo': Select(attrs={'class' :'select2',}),
			'modem_marca': Select(attrs={'class' :'select2'}),
			}




class Formulario_nom_teclado_marca(ModelForm):
	class Meta:
		model = nom_teclado_marca

class Formulario_nom_teclado_raton_tipo(ModelForm):
	class Meta:
		model = nom_teclado_raton_tipo

class Formulario_teclado(ModelForm):
	class Meta:
		model = teclado
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'teclado_tipo': Select(attrs={'class' :'select2',}),
			'teclado_marca': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_raton_marca(ModelForm):
	class Meta:
		model = nom_raton_marca

class Formulario_raton(ModelForm):
	class Meta:
		model = raton
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'capacidad': TextInput(attrs={'class' :'form-control'}),
			'raton_tipo': Select(attrs={'class' :'select2',}),
			'raton_marca': Select(attrs={'class' :'select2'}),
			}




class Formulario_nom_bocinas_marca(ModelForm):
	class Meta:
		model = nom_bocinas_marca




class Formulario_nom_monitor_marca(ModelForm):
	class Meta:
		model = nom_monitor_marca

class Formulario_nom_monitor_tipo(ModelForm):
	class Meta:
		model = nom_monitor_tipo

class Formulario_nom_monitor_dimension(ModelForm):
	class Meta:
		model = nom_monitor_dimension

class Formulario_monitor(ModelForm):
	class Meta:
		model = monitor
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'monitor_marca': Select(attrs={'class' :'select2',}),
			'monitor_dimension': Select(attrs={'class' :'select2'}),
			'monitor_tipo': Select(attrs={'class' :'select2'}),
			}



class Formulario_nom_impresora_marca(ModelForm):
	class Meta:
		model = nom_impresora_marca

class Formulario_nom_impresora_tipo(ModelForm):
	class Meta:
		model = nom_impresora_tipo

class Formulario_nom_impresora_interface(ModelForm):
	class Meta:
		model = nom_impresora_interface

class Formulario_impresora(ModelForm):
	class Meta:
		model = impresora
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'impresora_marca': Select(attrs={'class' :'select2',}),
			'impresora_inteface': Select(attrs={'class' :'select2'}),
			'impresora_tipo': Select(attrs={'class' :'select2'}),
			}



class Formulario_nom_scanner_marca(ModelForm):
	class Meta:
		model = nom_scanner_marca

class Formulario_nom_scanner_tipo(ModelForm):
	class Meta:
		model = nom_scanner_tipo

class Formulario_nom_scanner_dimension(ModelForm):
	class Meta:
		model = nom_scanner_dimension

class Formulario_nom_scanner_interface(ModelForm):
	class Meta:
		model = nom_scanner_interface

class Formulario_scanner(ModelForm):
	class Meta:
		model = scanner
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'scanner_marca': Select(attrs={'class' :'select2',}),
			'scanner_dimension': Select(attrs={'class' :'select2'}),
			'scanner_interface': Select(attrs={'class' :'select2'}),
			'scanner_tipo': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_ups_marca(ModelForm):
	class Meta:
		model = nom_ups_marca

class Formulario_nom_ups_tipo(ModelForm):
	class Meta:
		model = nom_ups_tipo

class Formulario_ups(ModelForm):
	class Meta:
		model = ups
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'ups_marca': Select(attrs={'class' :'select2',}),
			'ups_tipo': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_switch_marca(ModelForm):
	class Meta:
		model = nom_switch_marca

class Formulario_nom_switch_tipo(ModelForm):
	class Meta:
		model = nom_switch_tipo

class Formulario_switch(ModelForm):
	class Meta:
		model = switch
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'velocidad': TextInput(attrs={'class' :'form-control'}),
			'num_puertos': TextInput(attrs={'class' :'form-control'}),
			'switch_marca': Select(attrs={'class' :'select2',}),
			'switch_tipo': Select(attrs={'class' :'select2'}),
			'reponsable': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_camara_marca(ModelForm):
	class Meta:
		model = nom_camara_marca

class Formulario_nom_camara_tipo(ModelForm):
	class Meta:
		model = nom_camara_tipo

class Formulario_camara(ModelForm):
	class Meta:
		model = camara
		exclude=('pc', 'activo')
		widgets = {
			'reponsable': Select(attrs={'class' :'select2'}),
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'camara_marca': Select(attrs={'class' :'select2',}),
			'camara_tipo': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_stick_marca(ModelForm):
	class Meta:
		model = nom_stick_marca

class Formulario_nom_stick_tipo(ModelForm):
	class Meta:
		model = nom_stick_tipo

class Formulario_stick(ModelForm):
	class Meta:
		model = stick
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'velocidad': TextInput(attrs={'class' :'form-control'}),
			'stick_marca': Select(attrs={'class' :'select2',}),
			'stick_tipo': Select(attrs={'class' :'select2'}),
			'reponsable': Select(attrs={'class' :'select2'}),
			}


class Formulario_nom_ap_marca(ModelForm):
	class Meta:
		model = nom_ap_marca

class Formulario_nom_ap_tipo(ModelForm):
	class Meta:
		model = nom_ap_tipo

class Formulario_ap(ModelForm):
	class Meta:
		model = ap
		exclude=('pc', 'activo')
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control'}),
			'serie': TextInput(attrs={'class' :'form-control'}),
			'inventario': TextInput(attrs={'class' :'form-control'}),
			'velocidad': TextInput(attrs={'class' :'form-control'}),
			'ap_marca': Select(attrs={'class' :'select2',}),
			'ap_tipo': Select(attrs={'class' :'select2'}),
			'reponsable': Select(attrs={'class' :'select2'}),
			}
