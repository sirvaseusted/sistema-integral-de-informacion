from unidad.models import *
from equipamiento.models import *
from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from equipamiento.models import *
from unidad.models import *
from unidad.views import *
from rrhh.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from unidad.forms import *
from equipamiento.forms import  *
from django.db.models import Sum
from django.db.models import Count
#~ from reportlab.pdfgen import canvas
from django.http import HttpResponse
from django.views.generic import UpdateView




##################################
###### PORTADA EQUIPAMIENTO ######
##################################
@login_required(login_url='/ingresar')
def equipamiento(request):
	tab = request.GET.get('id')

	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	camaras = camara.objects.all()
	pcs = pc.objects.all()
	switchs = switch.objects.all()
	aps = ap.objects.all()
	teclados = teclado.objects.all()
	ratones = raton.objects.all()
	backup = ups.objects.all()
	printer = impresora.objects.all()
	return render_to_response('equipamiento/listar_equipamiento.html', {
	'printer':printer,
	'ratones':ratones,
	'backup':backup,
	'teclados':teclados,
	'switchs':switchs,
	'tab':tab,
	'aps':aps,
	'pcs':pcs,
	'camaras':camaras,
	'unidad':unidad}, context_instance=RequestContext(request))
##################################
###### PORTADA EQUIPAMIENTO ######
##################################



@login_required(login_url='/ingresar')
def tipoequipo(request):
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	return render_to_response('equipamiento/tipoequipo.html', {'unidad':unidad}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_pc(request):
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	return render_to_response('pc/registro_pc.html', {'unidad':unidad}, context_instance=RequestContext(request))

##########################################
###### INICIO SESION DE LA ESTACION ######
##########################################

@login_required(login_url='/ingresar')
def agregar_pc(request):

	if request.method=='POST':
		form_pc = Formulario_pc(request.POST)
		if form_pc.is_valid():
			form = form_pc.save(commit=False)
			form.save()
	else:
		form_pc = Formulario_pc()





	if request.method=='POST':
		form_chasis = Formulario_chasis(request.POST)
		if form_chasis.is_valid():
			form = form_chasis.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_chasis = Formulario_chasis()



	if request.method=='POST':
		form_teclado = Formulario_teclado(request.POST)
		if form_teclado.is_valid():
			form = form_teclado.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_teclado = Formulario_teclado()

	if request.method=='POST':
		form_raton = Formulario_raton(request.POST)
		if form_raton.is_valid():
			form = form_raton.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_raton = Formulario_raton()

	if request.method=='POST':
		form_monitor = Formulario_monitor(request.POST)
		if form_monitor.is_valid():
			form = form_monitor.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_monitor = Formulario_monitor()

	if request.method=='POST':
		form_impresora = Formulario_impresora(request.POST)
		if form_impresora.is_valid():
			form = form_impresora.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_impresora = Formulario_impresora()

	if request.method=='POST':
		form_scanner = Formulario_scanner(request.POST)
		if form_scanner.is_valid():
			form = form_scanner.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_scanner = Formulario_scanner()

	if request.method=='POST':
		form_switch = Formulario_switch(request.POST)
		if form_switch.is_valid():
			form = form_switch.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_switch = Formulario_switch()

	if request.method=='POST':
		form_camara = Formulario_camara(request.POST)
		if form_camara.is_valid():
			form = form_camara.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_camara = Formulario_camara()

	if request.method=='POST':
		form_stick = Formulario_stick(request.POST)
		if form_stick.is_valid():
			form = form_stick.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_stick = Formulario_stick()

	if request.method=='POST':
		form_ap = Formulario_ap(request.POST)
		if form_ap.is_valid():
			form = form_ap.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ap = Formulario_ap()

	if request.method=='POST':
		form_board_pc = Formulario_board_pc(request.POST)
		if form_board_pc.is_valid():
			form = form_board_pc.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_board_pc = Formulario_board_pc()

	if request.method=='POST':
		form_ups = Formulario_ups(request.POST)
		if form_ups.is_valid():
			form = form_ups.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ups = Formulario_ups()


















	if request.method=='POST':
		form_procesador = Formulario_procesador(request.POST)
		if form_procesador.is_valid():
			form = form_procesador.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_procesador = Formulario_procesador()

	if request.method=='POST':
		form_ram = Formulario_ram(request.POST)
		if form_ram.is_valid():
			form = form_ram.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ram = Formulario_ram()

	if request.method=='POST':
		form_hdd = Formulario_hdd(request.POST)
		if form_hdd.is_valid():
			form = form_hdd.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_hdd = Formulario_hdd()

	if request.method=='POST':
		form_fuente = Formulario_fuente(request.POST)
		if form_fuente.is_valid():
			form = form_fuente.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_fuente = Formulario_fuente()

	return render_to_response('pc/registro_pc.html', {
	'form_pc':form_pc,
	'form_board_pc':form_board_pc,
	'form_procesador':form_procesador,
	'form_ram':form_ram,
	'form_hdd':form_hdd,
	'form_fuente':form_fuente,
	'form_chasis':form_chasis,
	'form_teclado':form_teclado,
	'form_raton':form_raton,
	'form_monitor':form_monitor,
	'form_impresora':form_impresora,
	'form_scanner':form_scanner,
	'form_ups':form_ups,
	'form_switch':form_switch,
	'form_camara':form_camara,
	'form_stick':form_stick,
	'form_ap':form_ap,



		}, context_instance=RequestContext(request))

#######################################
###### FIN SESION DE LA ESTACION ######
#######################################



######################################
###### INICIO SESION DE CAMARAS ######
######################################


@login_required(login_url='/ingresar')
def editar_camara(request):
	id_equipo = request.GET.get('id')
	equipo=camara.objects.get(id=id_equipo)
	if request.method=='POST':
		form_camara = Formulario_camara(request.POST,instance=equipo)
		if form_camara.is_valid():
			form = form_camara.save(commit=False)
			form.save()
			acciones='La camara con marca '+ str(form.camara_marca) + " y tipo " + str(form.camara_tipo) + " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('camara/info_camara.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_camara = Formulario_camara(instance=equipo)
	return render_to_response('camara/registro_camara.html',{'form_camara':form_camara,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_camara(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_camara = Formulario_camara(request.POST)
		if form_camara.is_valid():
			form = form_camara.save(commit=False)
			form.activo = True
			form.save()
			acciones='La Camara con marca '+ str(form.camara_marca) + " y tipo  "+ str(form.camara_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('camara/info_camara.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_camara = Formulario_camara()
	return render_to_response('camara/registro_camara.html',{'form_camara':form_camara,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_camara(request):
	id_estacion = request.GET.get('id')
	estacion=camara.objects.get(id=id_estacion)
	return render_to_response('camara/info_camara.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_camara(request):
	id_estacion = request.GET.get('id')
	estacion=camara.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La camara ' + str(camara.camara_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=camara')

###################################
###### FIN SESION DE CAMARAS ######
###################################









############################################
###### INICIO DE SESION DE IMPRESORAS ######
############################################


@login_required(login_url='/ingresar')
def editar_impresora(request):
	id_equipo = request.GET.get('id')
	equipo=impresora.objects.get(id=id_equipo)
	if request.method=='POST':
		form_impresora = Formulario_impresora(request.POST,instance=equipo)
		if form_impresora.is_valid():
			form = form_impresora.save(commit=False)
			form.save()
			acciones='La impresora con marca '+ str(form.impresora_marca) + " y tipo  "+ str(form.impresora_tipo) + " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('impresora/info_impresora.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_impresora = Formulario_impresora(instance=equipo)
	return render_to_response('impresora/registro_impresora.html',{'form_impresora':form_impresora,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_impresora(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_impresora = Formulario_impresora(request.POST)
		if form_impresora.is_valid():
			form = form_impresora.save(commit=False)
			form.activo = True
			form.save()
			acciones='La impresora con marca '+ str(form.impresora_marca) + " y tipo  "+ str(form.impresora_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('impresora/info_impresora.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_impresora = Formulario_impresora()
	return render_to_response('impresora/registro_impresora.html',{'form_impresora':form_impresora,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_impresora(request):
	id_estacion = request.GET.get('id')
	estacion=impresora.objects.get(id=id_estacion)
	return render_to_response('impresora/info_impresora.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_impresora(request):
	id_estacion = request.GET.get('id')
	estacion=impresora.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La impresora ' + str(impresora.impresora_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=impresora')

######################################
###### FIN SESION DE IMPRESORAS ######
######################################








####################################
###### INICIO DE SESION DE AP ######
####################################


@login_required(login_url='/ingresar')
def editar_ap(request):
	id_equipo = request.GET.get('id')
	equipo=ap.objects.get(id=id_equipo)
	if request.method=='POST':
		form_ap = Formulario_ap(request.POST,instance=equipo)
		if form_ap.is_valid():
			form = form_ap.save(commit=False)
			form.save()
			acciones='La ap con marca '+ str(form.ap_marca) + " y tipo  "+ str(form.ap_tipo) + " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('ap/info_ap.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_ap = Formulario_ap(instance=equipo)
	return render_to_response('ap/registro_ap.html',{'form_ap':form_ap,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_ap(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_ap = Formulario_ap(request.POST)
		if form_ap.is_valid():
			form = form_ap.save(commit=False)
			form.activo = True
			form.save()
			acciones='La ap con marca '+ str(form.ap_marca) + " y tipo  "+ str(form.ap_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('ap/info_ap.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_ap = Formulario_ap()
	return render_to_response('ap/registro_ap.html',{'form_ap':form_ap,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_ap(request):
	id_estacion = request.GET.get('id')
	estacion=ap.objects.get(id=id_estacion)
	return render_to_response('ap/info_ap.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_ap(request):
	id_estacion = request.GET.get('id')
	estacion=ap.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La ap ' + str(ap.ap_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=ap')

##############################
###### FIN SESION DE AP ######
##############################





##############################################
###### INICIO DE SESION DE switch ######
##############################################


@login_required(login_url='/ingresar')
def editar_switch(request):
	id_equipo = request.GET.get('id')
	equipo=switch.objects.get(id=id_equipo)
	if request.method=='POST':
		form_switch = Formulario_switch(request.POST,instance=equipo)
		if form_switch.is_valid():
			form = form_switch.save(commit=False)
			form.save()
			acciones='La switch con marca '+ str(form.switch_marca) + " y tipo  "+ str(form.switch_tipo) + " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('switch/info_switch.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_switch = Formulario_switch(instance=equipo)
	return render_to_response('switch/registro_switch.html',{'form_switch':form_switch,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_switch(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_switch = Formulario_switch(request.POST)
		if form_switch.is_valid():
			form = form_switch.save(commit=False)
			form.activo = True
			form.save()
			acciones='La switch con marca '+ str(form.switch_marca) + " y tipo  "+ str(form.switch_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('switch/info_switch.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_switch = Formulario_switch()
	return render_to_response('switch/registro_switch.html',{'form_switch':form_switch,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_switch(request):
	id_estacion = request.GET.get('id')
	estacion=switch.objects.get(id=id_estacion)
	return render_to_response('switch/info_switch.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_switch(request):
	id_estacion = request.GET.get('id')
	estacion=switch.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La switch ' + str(switch.switch_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=switch')

######################################
###### FIN SESION DE switch ######
######################################






#####################################
###### INICIO DE SESION DE UPS ######
#####################################


@login_required(login_url='/ingresar')
def editar_ups(request):
	id_equipo = request.GET.get('id')
	equipo=ups.objects.get(id=id_equipo)
	if request.method=='POST':
		form_ups = Formulario_ups(request.POST,instance=equipo)
		if form_ups.is_valid():
			form = form_ups.save(commit=False)
			form.save()
			acciones='La ups con marca '+ str(form.ups_marca) + " y tipo  "+ str(form.ups_tipo) + " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('ups/info_ups.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_ups = Formulario_ups(instance=equipo)
	return render_to_response('ups/registro_ups.html',{'form_ups':form_ups,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_ups(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_ups = Formulario_ups(request.POST)
		if form_ups.is_valid():
			form = form_ups.save(commit=False)
			form.activo = True
			form.save()
			acciones='La ups con marca '+ str(form.ups_marca) + " y tipo  "+ str(form.ups_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('ups/info_ups.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_ups = Formulario_ups()
	return render_to_response('ups/registro_ups.html',{'form_ups':form_ups,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_ups(request):
	id_estacion = request.GET.get('id')
	estacion=ups.objects.get(id=id_estacion)
	return render_to_response('ups/info_ups.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_ups(request):
	id_estacion = request.GET.get('id')
	estacion=ups.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La ups ' + str(ups.ups_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=ups')

###############################
###### FIN SESION DE ups ######
###############################






#######################################
###### INICIO DE SESION DE RATON ######
#######################################


@login_required(login_url='/ingresar')
def editar_raton(request):
	id_equipo = request.GET.get('id')
	equipo=raton.objects.get(id=id_equipo)
	if request.method=='POST':
		form_raton = Formulario_raton(request.POST,instance=equipo)
		if form_raton.is_valid():
			form = form_raton.save(commit=False)
			form.save()
			acciones='La raton con marca '+ str(form.raton_marca) + " y tipo  "+ str(form.raton_tipo) + " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('raton/info_raton.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_raton = Formulario_raton(instance=equipo)
	return render_to_response('raton/registro_raton.html',{'form_raton':form_raton,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_raton(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_raton = Formulario_raton(request.POST)
		if form_raton.is_valid():
			form = form_raton.save(commit=False)
			form.activo = True
			form.save()
			acciones='La raton con marca '+ str(form.raton_marca) + " y tipo  "+ str(form.raton_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('raton/info_raton.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_raton = Formulario_raton()
	return render_to_response('raton/registro_raton.html',{'form_raton':form_raton,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_raton(request):
	id_estacion = request.GET.get('id')
	estacion=raton.objects.get(id=id_estacion)
	return render_to_response('raton/info_raton.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_raton(request):
	id_estacion = request.GET.get('id')
	estacion=raton.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La raton ' + str(raton.raton_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=raton')

#################################
###### FIN SESION DE RATON ######
#################################





#########################################
###### INICIO DE SESION DE TECLADO ######
#########################################


@login_required(login_url='/ingresar')
def editar_teclado(request):
	id_equipo = request.GET.get('id')
	equipo=teclado.objects.get(id=id_equipo)
	if request.method=='POST':
		form_teclado = Formulario_teclado(request.POST,instance=equipo)
		if form_teclado.is_valid():
			form = form_teclado.save(commit=False)
			form.save()
			acciones='La teclado con marca '+ str(form.teclado_marca) + " y tipo  "+ str(form.teclado_tipo) + " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('teclado/info_teclado.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_teclado = Formulario_teclado(instance=equipo)
	return render_to_response('teclado/registro_teclado.html',{'form_teclado':form_teclado,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_teclado(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_teclado = Formulario_teclado(request.POST)
		if form_teclado.is_valid():
			form = form_teclado.save(commit=False)
			form.activo = True
			form.save()
			acciones='La teclado con marca '+ str(form.teclado_marca) + " y tipo  "+ str(form.teclado_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('teclado/info_teclado.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_teclado = Formulario_teclado()
	return render_to_response('teclado/registro_teclado.html',{'form_teclado':form_teclado,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_teclado(request):
	id_estacion = request.GET.get('id')
	estacion=teclado.objects.get(id=id_estacion)
	return render_to_response('teclado/info_teclado.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_teclado(request):
	id_estacion = request.GET.get('id')
	estacion=teclado.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La teclado ' + str(teclado.teclado_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=teclado')

###################################
###### FIN SESION DE teclado ######
###################################





####################################
###### INICIO DE SESION DE PC ######
####################################


@login_required(login_url='/ingresar')
def editar_pc(request):
	id_equipo = request.GET.get('id')
	equipo=pc.objects.get(id=id_equipo)
	if request.method=='POST':
		form_pc = Formulario_pc(request.POST,instance=equipo)
		if form_pc.is_valid():
			form = form_pc.save(commit=False)
			form.save()
			acciones='La pc con marca '+ str(form.pc_marca) + " y tipo  "+ str(form.pc_tipo) + " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('pc/info_pc.html',{'entity':form,} , context_instance=RequestContext(request))
	else:
		form_pc = Formulario_pc(instance=equipo)
	return render_to_response('pc/registro_pc.html',{'form_pc':form_pc,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_pc(request):
	id_unidad = request.GET.get('id')
	if request.method=='POST':
		form_pc = Formulario_pc(request.POST)
		if form_pc.is_valid():
			form = form_pc.save(commit=False)
			form.activo = True
			form.save()
			acciones='La pc con marca '+ str(form.pc_marca) + " y tipo  "+ str(form.pc_tipo) + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('pc/info_pc.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_pc = Formulario_pc()
	return render_to_response('pc/registro_pc.html',{'form_pc':form_pc,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_pc(request):
	id_estacion = request.GET.get('id')
	estacion=pc.objects.get(id=id_estacion)
	return render_to_response('pc/info_pc.html',{'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_pc(request):
	id_estacion = request.GET.get('id')
	estacion=pc.objects.get(id=id_estacion)
	estacion.delete()
	acciones='La pc ' + str(pc.pc_marca) + " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('equipamiento?id=pc')

##############################
###### FIN SESION DE PC ######
##############################














from django.shortcuts import render_to_response
from django.contrib.formtools.wizard.views import SessionWizardView

class ContactWizard(SessionWizardView):
	def done(self, form_list, **kwargs):
		return HttpResponseRedirect('/equipamiento?id=pc')



#~ class ContactWizard(SessionWizardView):
	#~ def done(self, form_list, **kwargs):
		#~ return render_to_response('done.html', {
			#~ 'form_data': [form.cleaned_data for form in form_list],
		#~ })
