from unidad.models import *
from equipamiento.models import *
from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from equipamiento.models import *
from unidad.models import *
from unidad.views import *
from rrhh.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from unidad.forms import *
from equipamiento.forms import  *
from django.db.models import Sum
from django.db.models import Count
from reportlab.pdfgen import canvas
from django.http import HttpResponse
from django.views.generic import UpdateView

@login_required(login_url='/ingresar')
def equipamiento(request):
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	camaras = camara.objects.all()
	pcs = pc.objects.all()
	return render_to_response('equipamiento/equipamiento.html', {'pcs':pcs,'camaras':camaras, 'unidad':unidad}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def tipoequipo(request):
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	return render_to_response('equipamiento/tipoequipo.html', {'unidad':unidad}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def registro_pc(request):
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	return render_to_response('registro_pc.html', {'unidad':unidad}, context_instance=RequestContext(request))

#REGISTRANDO LA PC COMO ESTACION DE TRABAJO 
@login_required(login_url='/ingresar')
def agregar_pc(request):

	if request.method=='POST':
		form_pc = Formulario_pc(request.POST)
		if form_pc.is_valid():
			form = form_pc.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_pc = Formulario_pc()

	if request.method=='POST':
		form_procesador = Formulario_procesador(request.POST)
		if form_procesador.is_valid():
			form = form_procesador.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_procesador = Formulario_procesador()

	if request.method=='POST':
		form_ram = Formulario_ram(request.POST)
		if form_ram.is_valid():
			form = form_ram.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ram = Formulario_ram()

	if request.method=='POST':
		form_hdd = Formulario_hdd(request.POST)
		if form_hdd.is_valid():
			form = form_hdd.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_hdd = Formulario_hdd()

	if request.method=='POST':
		form_fuente = Formulario_fuente(request.POST)
		if form_fuente.is_valid():
			form = form_fuente.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_fuente = Formulario_fuente()

	if request.method=='POST':
		form_chasis = Formulario_chasis(request.POST)
		if form_chasis.is_valid():
			form = form_chasis.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_chasis = Formulario_chasis()

	if request.method=='POST':
		form_teclado = Formulario_teclado(request.POST)
		if form_teclado.is_valid():
			form = form_teclado.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_teclado = Formulario_teclado()

	if request.method=='POST':
		form_raton = Formulario_raton(request.POST)
		if form_raton.is_valid():
			form = form_raton.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_raton = Formulario_raton()

	if request.method=='POST':
		form_monitor = Formulario_monitor(request.POST)
		if form_monitor.is_valid():
			form = form_monitor.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_monitor = Formulario_monitor()

	if request.method=='POST':
		form_impresora = Formulario_impresora(request.POST)
		if form_impresora.is_valid():
			form = form_impresora.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_impresora = Formulario_impresora()

	if request.method=='POST':
		form_scanner = Formulario_scanner(request.POST)
		if form_scanner.is_valid():
			form = form_scanner.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_scanner = Formulario_scanner()

	if request.method=='POST':
		form_switch = Formulario_switch(request.POST)
		if form_switch.is_valid():
			form = form_switch.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_switch = Formulario_switch()

	if request.method=='POST':
		form_camara = Formulario_camara(request.POST)
		if form_camara.is_valid():
			form = form_camara.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_camara = Formulario_camara()

	if request.method=='POST':
		form_stick = Formulario_stick(request.POST)
		if form_stick.is_valid():
			form = form_stick.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_stick = Formulario_stick()

	if request.method=='POST':
		form_ap = Formulario_ap(request.POST)
		if form_ap.is_valid():
			form = form_ap.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ap = Formulario_ap()

	if request.method=='POST':
		form_board_pc = Formulario_board_pc(request.POST)
		if form_board_pc.is_valid():
			form = form_board_pc.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_board_pc = Formulario_board_pc()

	if request.method=='POST':
		form_ups = Formulario_ups(request.POST)
		if form_ups.is_valid():
			form = form_ups.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ups = Formulario_ups()



	return render_to_response('equipamiento/registro_pc.html', {
	'form_pc':form_pc,
	'form_board_pc':form_board_pc,
	'form_procesador':form_procesador,
	'form_ram':form_ram,
	'form_hdd':form_hdd,
	'form_fuente':form_fuente,
	'form_chasis':form_chasis,
	'form_teclado':form_teclado,
	'form_raton':form_raton,
	'form_monitor':form_monitor,
	'form_impresora':form_impresora,
	'form_scanner':form_scanner,
	'form_ups':form_ups,
	'form_switch':form_switch,
	'form_camara':form_camara,
	'form_stick':form_stick,
	'form_ap':form_ap,



		}, context_instance=RequestContext(request))


#REGISTRANDO TECLADO INDEPENDIENTE
@login_required(login_url='/ingresar')
def registro_kb(request):
	if request.method=='POST':
		form_teclado = Formulario_teclado(request.POST)
		if form_teclado.is_valid():
			form = form_teclado.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_teclado = Formulario_teclado()
	return render_to_response('equipamiento/registro_kb.html', {'form_teclado':form_teclado}, context_instance=RequestContext(request))
##############################

#REGISTRANDO RATON DE MANERA INDEPENDIENTE
@login_required(login_url='/ingresar')
def registro_raton(request):
	if request.method=='POST':
		form_nom_teclado_raton_tipo = Formulario_nom_teclado_raton_tipo(request.POST)
		if form_nom_teclado_raton_tipo.is_valid():
			form = form_nom_teclado_raton_tipo.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_teclado = Formulario_teclado()
	return render_to_response('equipamiento/registro_raton.html', {'form_teclado':form_teclado}, context_instance=RequestContext(request))
############################## 

#REGISTRO DE UPS DE MANERA INDEPENDIENTE
@login_required(login_url='/ingresar')
def registro_ups(request):
	if request.method=='POST':
		form_ups = Formulario_ups(request.POST)
		if form_ups.is_valid():
			form = form_ups.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ups = Formulario_ups()
	return render_to_response('equipamiento/registro_ups.html', {'form_ups':form_ups}, context_instance=RequestContext(request))
##############################


















#REGISTRANDO SWITCH
@login_required(login_url='/ingresar')
def registro_switch(request):
	if request.method=='POST':
		form_switch = Formulario_switch(request.POST)
		if form_switch.is_valid():
			form = form_switch.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_switch = Formulario_switch()
	return render_to_response('equipamiento/registro_switch.html', {'form_switch':form_switch}, context_instance=RequestContext(request))
##############################















#REGISTRANDO PUNTO DE ACCESO WIFI
@login_required(login_url='/ingresar')
def registro_ap(request):
	if request.method=='POST':
		form_ap = Formulario_ap(request.POST)
		if form_ap.is_valid():
			form = form_ap.save(commit=False)
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_ap = Formulario_ap()
	return render_to_response('equipamiento/registro_ap.html', {'form_ap':form_ap}, context_instance=RequestContext(request))
##############################

























#EDITAR CAMARA
@login_required(login_url='/ingresar')
def editar_camara(request):
	id_camara = request.GET.get('id')
	cam=camara.objects.get(id=id_camara)
	if request.method=='POST':
		form_camara = Formulario_camara(request.POST, instance=cam)
		if form_camara.is_valid():
			form = form_camara.save(commit=False)
			form.activo = True
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_camara = Formulario_camara(instance=cam)
	return render_to_response('equipamiento/registro_camara.html', {'form_camara':form_camara}, context_instance=RequestContext(request))
##############################

#REGISTRANDO CAMARA
@login_required(login_url='/ingresar')
def registro_camara(request):
	if request.method=='POST':
		form_camara = Formulario_camara(request.POST)
		if form_camara.is_valid():
			form = form_camara.save(commit=False)
			form.activo = True
			form.save()
			return HttpResponseRedirect('/equipamientos')
	else:
		form_camara = Formulario_camara()
	return render_to_response('equipamiento/registro_camara.html', {'form_camara':form_camara}, context_instance=RequestContext(request))
##############################

#BORRANDO CAMARA
@login_required(login_url='/ingresar')
def borrar_camara(request):
	id_camara = request.GET.get('id')
	camaras = camara.objects.get(id=id_camara)
	#~ id_user=request.session['userid']
	#~ trabajador = Trabajador.objects.get(id=id_user)
	#~ permiso=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
#~ 
	#~ if permiso ==2 or permiso == 0:
		#~ return HttpResponseRedirect('/')

	camaras.delete()
	acciones='La camara '+ str(camaras.camara_marca) + " de la Unidad "+ str(camaras.reponsable.plaza_ocupa.departamento.unidad.nombre) + " fue eliminado"
	registrar_log(request,acciones,3)
	camaras = camara.objects.all().order_by('-id')
	return HttpResponseRedirect('/equipamientos')
##############################
