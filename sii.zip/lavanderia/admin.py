from django.contrib import admin
from lavanderia.models import  *

class producto_admin(admin.ModelAdmin):
	pass 
admin.site.register(producto, producto_admin)

class reporte_admin(admin.ModelAdmin):
	list_display=('producto', 'unidad', 'cantidad', 'fecha', 'actualizacion')
	list_per_page=30
admin.site.register(reporte, reporte_admin)
