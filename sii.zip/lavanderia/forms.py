from django.forms import *
from django import forms
from lavanderia.models import *


class formulario_reporte(ModelForm):
	class Meta:
		model = reporte
		widgets = {
'producto': Select(attrs={"class" :"select2",'placeholder': 'producto'}),
'unidad': Select(attrs={"class" :"select2",'placeholder': 'unidad'}),
'cantidad': TextInput(attrs={'class' :'form-control','placeholder': 'cantidad'}),
'fecha': TextInput(attrs={'class' :'form-control','placeholder': 'fecha'})
}
