from django.forms import *
from django import forms
from alimentos.models import *


class formulario_reporte(ModelForm):
	class Meta:
		model = alimentos
		widgets = {
'producto': Select(attrs={"class" :"select2",'placeholder': 'producto'}),
'unidad': Select(attrs={"class" :"select2",'placeholder': 'unidad'}),
'existencia': TextInput(attrs={'class' :'form-control','placeholder': 'existencia'}),
'fecha': TextInput(attrs={'class' :'form-control','placeholder': 'fecha'})
}
