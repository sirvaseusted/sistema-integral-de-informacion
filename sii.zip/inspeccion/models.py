from django.db import models
from rrhh.models import *
from unidad.models import *
from tareas.models import *

class Nom_Estado_Deficiencia(models.Model):
	estado = models.CharField('Tipo de Estado', max_length = 250, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length = 250, blank=True)
	def __unicode__(self):
		return '%s' % (self.estado)
		
class Nom_Aspecto_Deficiencia(models.Model):
	aspecto = models.CharField('Tipo de Estado', max_length = 250, unique=True, null=True)
	activo = models.BooleanField('Estado', max_length = 250, blank=True)
	def __unicode__(self):
		return '%s' % (self.aspecto)

class Nom_Tipo_Visita(models.Model):
	tipo = models.CharField('Tipo de Tarea', max_length = 250, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length = 250, blank=True)
	def __unicode__(self):
		return '%s' % (self.tipo)


class Visita(models.Model):
	tipo = models.ForeignKey(Nom_Tipo_Visita, max_length = 250, blank=True, null=True)
	unidad = models.ForeignKey(Unidad, related_name='visitas',max_length = 250, blank=True, null=True)
	fecha = models.DateTimeField('Fecha de la visita', auto_now=True, auto_now_add=True)
	visitado = models.CharField('Visitado', max_length = 250, blank=True, null=True)
	participantes = models.ManyToManyField(Trabajador, max_length = 250, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length = 250, blank=True)
	def __unicode__(self):
		return 'Visita a la unidad %s de %s el %s' % (self.unidad.nombre,self.unidad.municipio.municipio,self.fecha)

class Deficiencia(models.Model):
	visita = models.ForeignKey(Visita,related_name='deficiencias', max_length = 250, blank=True, null=True)
	deficiencia = models.CharField('Deficiencia', max_length = 250, blank=True, null=True)
	estado = models.ForeignKey(Nom_Estado_Deficiencia, max_length = 250, blank=True, null=True)
	aspecto = models.ForeignKey(Nom_Aspecto_Deficiencia, max_length = 250, blank=True, null=True)
	observaciones = models.TextField('Observaciones', max_length = 250, blank=True, null=True)
	fechafin = models.DateTimeField('Fecha de cierre de la deficiencia', auto_now=False, auto_now_add=False, null=True)
	puntoaspecto = models.CharField('punto de aspecto', max_length = 250, blank=True, null=True)
	tarea = models.ManyToManyField(Tarea,through='deficienciasXtareas') 
	activo = models.BooleanField('Estado', max_length = 250, blank=True)
	def __unicode__(self):
		return 'Deficiencia %s detectada en la unidad %s de %s el %s' % (self.deficiencia,self.visita.unidad.nombre,self.visita.unidad.municipio.municipio,self.visita.fecha)

class deficienciasXtareas(models.Model): 
	tarea = models.ForeignKey(Tarea,related_name='deficient') 
	deficiencia = models.ForeignKey(Deficiencia) 
