from django.forms import *
from django import forms
from investigacion.models import *


class formulario_publicaciones(ModelForm):
	class Meta:
		model = publicaciones
		exclude = ("anno",)

		widgets = {
'titulo': TextInput(attrs={"class" :"form-control",'placeholder': ' '}),
'tipo': Select(attrs={"class" :"select2",'placeholder': ' '}),
'nombrerevista': TextInput(attrs={"class" :"form-control",'placeholder': ' '}),
'isbn': TextInput(attrs={"class" :"form-control",'placeholder': ' '}),
'nroautores': TextInput(attrs={"class" :"form-control",'placeholder': 'Numero de Autores','required':'True','data-parsley-min':'5' }),



'autorprincipal': Select(attrs={"class" :"select2",'placeholder': ' '}),

}
