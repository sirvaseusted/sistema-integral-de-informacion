from django.forms import *
from django import forms
from galeria.models import *

class Formulario_Galeria(ModelForm):
	class Meta:
		model = imagenes
		exclude=('estado','unidad')
		widgets = {
			'categoria': Select(attrs={'class' :'select2','placeholder': 'Categoria','required':'false'}),
			'titulo': TextInput(attrs={'class' :'form-control','placeholder': 'Titulo','required':'true'}),
			'descripcion': Textarea(attrs={'class' :'form-control','placeholder': 'Descripcion','required':'true'}),
			}

