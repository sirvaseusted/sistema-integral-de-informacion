from django.shortcuts import render

# Create your views here.

from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from galeria.models import *
from unidad.views import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from galeria.forms import  Formulario_Galeria
from django.db.models import Sum
from django.db.models import Count


from django.views.generic import UpdateView

@login_required(login_url='/ingresar')
def galeria(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	
	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	for unidad1 in unidades: 
		for perfil1 in perfiles: 
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad1.id]=unidad1.id
	return render_to_response('galeria/galeria.unidades.sub.html',{'unidades':unidades,'unidad':unidad, 'perfil':perfil}, context_instance=RequestContext(request))




@login_required(login_url='/ingresar')
def gal(request):
	idunidad = request.GET.get('id')
	id_unidad=request.session['unidad']
	unidad=Unidad.objects.get(id=idunidad)
	img = imagenes.objects.filter(unidad=idunidad)
	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	for unidad1 in unidades: 
		for perfil1 in perfiles: 
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad1.id]=unidad1.id
	return render_to_response('galeria/galeria.html',{'img':img, 'perfil':perfil, 'unidad':unidad}, context_instance=RequestContext(request))





@login_required(login_url='/ingresar')
def form_gal(request):
	id_unidad = request.GET.get('id')
	unidad=Unidad.objects.get(id=id_unidad)
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_gal = Formulario_Galeria(request.POST, request.FILES)
		if form_gal.is_valid():
			form = form_gal.save(commit=False)
			form.unidad=id_unidad
			form.estado=True
			form.save()
			acciones='La imagen '+ form.titulo + " fue agregada a la unidad "+ form.unidad
			registrar_log(request,acciones,4)
			return render_to_response('galeria/formulario.galeria.html',{'form_gal':form_gal, 'unidad':unidad} , context_instance=RequestContext(request))
	else:
		form_gal = Formulario_Galeria()
	return render_to_response('galeria/formulario.galeria.html',{'form_gal':form_gal, 'unidad':unidad} , context_instance=RequestContext(request))

