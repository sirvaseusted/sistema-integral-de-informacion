from django.shortcuts import render

#-------------------------------------------------------------------------------------------------------#

from unidad.views import *
from django.contrib.auth.decorators import login_required
from carpeta.forms import *
from django.db.models import Count

#-------------------------------------------------------------------------------------------------------#

# Create your views here.
# Aqui comienzan las vistas relacionadas con los retiros
@login_required(login_url='/ingresar')
def retiros(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	#retiros realizados
	retir = Ficheros.objects.filter(unidad=request.session['unidad'])
	#documentos oficiales subidos por el usuario
	fichero = retiros.objects.filter(retiro=retir, unidad =request.session['unidad'])
	files = []
	for file in fichero:
		files.append(file.retiro)
	unidad= Unidad.objects.get(id=id_unidad)

	unidades= Unidad.objects.annotate(cantidad_retiros=Count('retiros__unidad')).filter(subordinacion=request.session['unidad']).order_by('-municipio')


	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	for unidad1 in unidades:
		for perfil1 in perfiles:
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad1.id]=unidad1.id
	return render_to_response('documento/documentos.html',{
	'document':retir,
	'fichero':fichero,
	'files':files,
	'id_unidad':id_unidad,
	'unidades':unidades,
	'perfil':perfil,
	'unidad':unidad
	}, context_instance=RequestContext(request))
