from django.contrib import admin
from alimentos.models import  *


class tipo_admin(admin.ModelAdmin):
	pass 
admin.site.register(tipo, tipo_admin)

class producto_admin(admin.ModelAdmin):
	pass 
admin.site.register(producto, producto_admin)

class alimentos_admin(admin.ModelAdmin):
	list_per_page=30
admin.site.register(alimentos, alimentos_admin)
