from django.db import models
from unidad.models import *


class tipo(models.Model):
	nombre=models.CharField('Tipo',max_length=30,blank=True,null=True)
	def __unicode__(self):
		return '%s' % (self.nombre)

class producto(models.Model):
	nombre=models.CharField('Producto',max_length=30,blank=True,null=True)
	tipo=models.ForeignKey(tipo,max_length=30,blank=True,null=True)
	def __unicode__(self):
		return '%s' % (self.nombre)


class alimentos(models.Model):
	producto=models.ForeignKey(producto,max_length=30,blank=True,null=True)
	unidad=models.ForeignKey(Unidad,max_length=30,blank=True,null=True)
	existencia=models.IntegerField('Existencia',max_length=30,blank=True,null=True)
	fecha= models.DateTimeField('Fecha de Reporte',auto_now=False, auto_now_add=False, blank=True, null=True)
	actualizacion= models.DateTimeField('Actualizado',auto_now=True, auto_now_add=True)




