from django.forms import *
from django import forms
from radio.models import *

class Formulario_Estacion_Fija(ModelForm):
	class Meta:
		model = estaciones_fijas
		exclude=('id_estado',)
		widgets = {
			'indicativo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'modelo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'estado': Select(attrs={'class' :'select2','required':'true'}),
			'marca': Select(attrs={'class' :'select2','required':'true'}),
			'ubicacion': Select(attrs={'class' :'select2','required':'true'}),
			}

class Formulario_Estacion_Movil(ModelForm):
	class Meta:
		model = estaciones_movil
		exclude=('id_estado',)
		widgets = {
			'indicativo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'modelo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'estado': Select(attrs={'class' :'select2','required':'true'}),
			'marca': Select(attrs={'class' :'select2','required':'true'}),
			'ubicacion': Select(attrs={'class' :'select2','required':'true'}),
			'movil': Select(attrs={'class' :'select2','required':'true'}),
			}

class Formulario_Estacion_Portatil(ModelForm):
	class Meta:
		model = estaciones_portatiles
		exclude=('id_estado',)
		widgets = {
			'indicativo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'modelo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'estado': Select(attrs={'class' :'select2','required':'true'}),
			'marca': Select(attrs={'class' :'select2','required':'true'}),
			'responsable': Select(attrs={'class' :'select2','required':'true'}),
			}
			
class Formulario_Estacion_Repetidora(ModelForm):
	class Meta:
		model = estaciones_repetidoras
		exclude=('id_estado',)
		widgets = {
			'modelo': TextInput(attrs={'class' :'form-control','required':'true'}),
			'estado': Select(attrs={'class' :'select2','required':'true'}),
			'marca': Select(attrs={'class' :'select2','required':'true'}),
			'ubicacion': TextInput(attrs={'class' :'form-control','required':'true'}),
			}
