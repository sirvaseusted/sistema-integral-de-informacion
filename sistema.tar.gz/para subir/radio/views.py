from django.shortcuts import render
from radio.models import *
from rrhh.models import *
from unidad.models import *
from transporte.models import *
from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.views import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from radio.forms import  *
from django.db.models import Sum
from django.db.models import Count

from django.http import HttpResponse
from django.views.generic import UpdateView


@login_required(login_url='/ingresar')
def listar_radio(request):
	if request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	perfil = Perfil.objects.get(user=request.session['userid'])
	tab = request.GET.get('id')
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	estaciones1=  estaciones_fijas.objects.all()
	estaciones_moviles1=estaciones_movil.objects.all()
	estaciones_portatil1=estaciones_portatiles.objects.all()
	estaciones_repetidorass=estaciones_repetidoras.objects.all()
	if perfil.user.is_staff:
		estaciones = estaciones1
		estaciones_moviles = estaciones_moviles1
		estaciones_portatil = estaciones_portatil1
	else:
		estaciones=[]
		estaciones_moviles=[]
		estaciones_portatil=[]

		for estacion in estaciones1:
			if estacion.ubicacion.unidad == unidad:
				estaciones.append(estacion)
		for estacionm in estaciones_moviles1:
			if estacionm.ubicacion.unidad == unidad:
				estaciones_moviles.append(estacionm)
		for estacionp in estaciones_portatil1:
			if estacionp.responsable.plaza_ocupa.departamento.unidad == unidad:
				estaciones_portatil.append(estacionp)
	return render_to_response('radio/listar_radio.html', { 'unidad':unidad,'estaciones_portatil':estaciones_portatil,'estaciones_repetidorass':estaciones_repetidorass,'estaciones':estaciones,'estaciones_moviles':estaciones_moviles,'tab':tab}, context_instance=RequestContext(request))

# Estaciones Fijas
@login_required(login_url='/ingresar')
def editar_estacion_fija(request):
	id_equipo = request.GET.get('id')
	equipo=estaciones_fijas.objects.get(id=id_equipo)
	departamentos = Departamento.objects.filter(unidad=equipo.ubicacion.unidad) 
	permiso=comprobar_perfil(request,equipo.ubicacion.unidad.id)
	if permiso ==2 or permiso == 0 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	if request.method=='POST':
		form_estacion_fija = Formulario_Estacion_Fija(request.POST,instance=equipo)
		if form_estacion_fija.is_valid():
			form = form_estacion_fija.save(commit=False)
			form.save()
			acciones='La Estacion Fija con indicativo '+ form.indicativo + " de la Unidad "+ form.ubicacion.unidad.nombre+ " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('estaciones_fijas/info_estacion_fija.html',{'entity':form,'editar':permiso,} , context_instance=RequestContext(request))
	else:
		form_estacion_fija = Formulario_Estacion_Fija(instance=equipo)
	return render_to_response('estaciones_fijas/editar_estacion_fija.html',{'form_estacion_fija':form_estacion_fija,'departamentos':departamentos,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def agregar_estacion_fija(request):
	if request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	id_unidad = request.GET.get('id')
	departamentos = Departamento.objects.filter(unidad=id_unidad)  
	if request.method=='POST':
		form_estacion_fija = Formulario_Estacion_Fija(request.POST)
		if form_estacion_fija.is_valid():
			form = form_estacion_fija.save(commit=False)
			form.save()
			acciones='La Estacion Fija con indicativo '+ form.indicativo + "de la Unidad "+ form.ubicacion.unidad.nombre+ " fue agregado"
			registrar_log(request,acciones,2)
			edita=1
			return render_to_response('estaciones_fijas/info_estacion_fija.html',{'entity':form,'editar':edita} , context_instance=RequestContext(request))
	else:
		form_estacion_fija = Formulario_Estacion_Fija()
	return render_to_response('estaciones_fijas/agregar_estacion_fija.html',{'form_estacion_fija':form_estacion_fija,'departamentos':departamentos,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_estacion_fija(request):
	id_estacion = request.GET.get('id')
	estacion=estaciones_fijas.objects.get(id=id_estacion)
	id_unidad=estacion.ubicacion.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('estaciones_fijas/info_estacion_fija.html',{'unidad':unidad[0],'editar':permiso,'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_estacion_fija(request):
	id_estacion = request.GET.get('id')
	estacion=estaciones_fijas.objects.get(id=id_estacion)
	id_unidad=estacion.ubicacion.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/')
	estacion.delete()
	acciones='La Estacion fija con indicativo '+ estacion.indicativo + " de marca " + estacion.marca.marca + " de la Unidad "+ estacion.ubicacion.unidad.nombre+ " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('listar_radio?id=fija')
	
	
# Estaciones Moviles
@login_required(login_url='/ingresar')
def editar_estacion_movil(request):
	id_equipo = request.GET.get('id')
	equipo=estaciones_movil.objects.get(id=id_equipo)
	departamentos = Departamento.objects.filter(unidad=equipo.ubicacion.unidad) 
	todos_moviles = movil.objects.all().annotate(esta = Count('estaciones_movil__movil'))
	moviles=[]
	for movil1 in todos_moviles:
		if movil1.esta == 0:
			moviles.append(movil1)
	moviles.append(equipo.movil)
	permiso=comprobar_perfil(request,equipo.ubicacion.unidad.id)
	if permiso ==2 or permiso == 0 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	if request.method=='POST':
		form_estacion_movil = Formulario_Estacion_Movil(request.POST,instance=equipo)
		if form_estacion_movil.is_valid():
			form = form_estacion_movil.save(commit=False)
			form.save()
			acciones='La Estacion Movil con indicativo '+ form.indicativo + ' y marca '+ form.marca.marca + " de la Unidad "+ form.ubicacion.unidad.nombre+ " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('estaciones_moviles/info_estacion_movil.html',{'entity':form,'editar':permiso,} , context_instance=RequestContext(request))
	else:
		form_estacion_movil = Formulario_Estacion_Movil(instance=equipo)
	return render_to_response('estaciones_moviles/editar_estacion_movil.html',{'form_estacion_movil':form_estacion_movil,'departamentos':departamentos,'equipo':equipo,'moviles':moviles,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def agregar_estacion_movil(request):
	if request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	id_unidad = request.GET.get('id')
	todos_moviles = parque.objects.all().annotate(esta = Count('estaciones_movil__movil'))
	moviles=[]
	for movil1 in todos_moviles:
		if movil1.esta == 0:
			moviles.append(movil1)
	departamentos = Departamento.objects.filter(unidad=id_unidad)  
	if request.method=='POST':
		form_estacion_movil = Formulario_Estacion_Movil(request.POST)
		if form_estacion_movil.is_valid():
			form = form_estacion_movil.save(commit=False)
			form.save()
			acciones='La Estacion Movil con indicativo '+ form.indicativo + ' y marca '+ form.marca.marca + " de la Unidad "+ form.ubicacion.unidad.nombre+ " fue agregado"
			registrar_log(request,acciones,2)
			edita=1
			return render_to_response('estaciones_moviles/info_estacion_movil.html',{'entity':form,'editar':edita} , context_instance=RequestContext(request))
	else:
		form_estacion_movil = Formulario_Estacion_Movil()
	return render_to_response('estaciones_moviles/agregar_estacion_movil.html',{'form_estacion_movil':form_estacion_movil,'departamentos':departamentos,'moviles':moviles,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_estacion_movil(request):
	id_estacion = request.GET.get('id')
	estacion=estaciones_movil.objects.get(id=id_estacion)
	id_unidad=estacion.ubicacion.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('estaciones_moviles/info_estacion_movil.html',{'unidad':unidad[0],'editar':permiso,'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_estacion_movil(request):
	id_estacion = request.GET.get('id')
	estacion=estaciones_movil.objects.get(id=id_estacion)
	id_unidad=estacion.ubicacion.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/')
	estacion.delete()
	acciones='La Estacion movil con indicativo '+ estacion.indicativo + " de marca " + estacion.marca.marca + " y modelo " + estacion.modelo + " de la Unidad "+ estacion.ubicacion.unidad.nombre+ " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('listar_radio?id=movil')

# Estaciones Portatil
@login_required(login_url='/ingresar')
def editar_estacion_portatil(request):
	id_equipo = request.GET.get('id')
	equipo=estaciones_portatiles.objects.get(id=id_equipo)
	trabajadoress = Trabajador.objects.all()
	responsables = []
	for trabajador in trabajadoress:
		if str(trabajador.plaza_ocupa.departamento.unidad.id)==str(request.session['unidad']):
			responsables.append(trabajador)
	permiso=comprobar_perfil(request,equipo.responsable.plaza_ocupa.departamento.unidad.id)
	if permiso ==2 or permiso == 0 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	if request.method=='POST':
		form_estacion_portatil = Formulario_Estacion_Portatil(request.POST,instance=equipo)
		if form_estacion_portatil.is_valid():
			form = form_estacion_portatil.save(commit=False)
			form.save()
			acciones='La Estacion Portatil con indicativo '+ form.indicativo + ' y marca '+ form.marca.marca + " de la Unidad "+ form.responsable.plaza_ocupa.departamento.unidad.nombre+ " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('estaciones_portatiles/info_estacion_portatil.html',{'entity':form,'editar':permiso,} , context_instance=RequestContext(request))
	else:
		form_estacion_portatil = Formulario_Estacion_Portatil(instance=equipo)
	return render_to_response('estaciones_portatiles/editar_estacion_portatil.html',{'form_estacion_portatil':form_estacion_portatil,'responsables':responsables,'equipo':equipo,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def agregar_estacion_portatil(request):
	if request.session['radio']=='no tiene':
		return HttpResponseRedirect('/') 
	id_unidad = request.GET.get('id')
	trabajadoress = Trabajador.objects.all()
	responsables = []
	for trabajador in trabajadoress:
		if str(trabajador.plaza_ocupa.departamento.unidad.id)==str(request.session['unidad']):
			responsables.append(trabajador)
	if request.method=='POST':
		form_estacion_portatil = Formulario_Estacion_Portatil(request.POST)
		if form_estacion_portatil.is_valid():
			form = form_estacion_portatil.save(commit=False)
			form.save()
			acciones='La Estacion Portatil con indicativo '+ form.indicativo + ' y marca '+ form.marca.marca + " de la Unidad "+ form.responsable.plaza_ocupa.departamento.unidad.nombre+ " fue agregado"
			registrar_log(request,acciones,2)
			edita=1
			return render_to_response('estaciones_portatiles/info_estacion_portatil.html',{'entity':form,'editar':edita} , context_instance=RequestContext(request))
	else:
		form_estacion_portatil = Formulario_Estacion_Portatil()
	return render_to_response('estaciones_portatiles/agregar_estacion_portatil.html',{'form_estacion_portatil':form_estacion_portatil,'responsables':responsables,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_estacion_portatil(request):
	id_estacion = request.GET.get('id')
	estacion=estaciones_portatiles.objects.get(id=id_estacion)
	id_unidad=estacion.responsable.plaza_ocupa.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('estaciones_portatiles/info_estacion_portatil.html',{'unidad':unidad[0],'editar':permiso,'entity':estacion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_estacion_portatil(request):
	id_estacion = request.GET.get('id')
	estacion=estaciones_portatiles.objects.get(id=id_estacion)
	id_unidad=estacion.responsable.plaza_ocupa.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or request.session['radio']=='no tiene':
		return HttpResponseRedirect('/')
	estacion.delete()
	acciones='La Estacion Portatil con indicativo '+ estacion.indicativo + 'y marca '+ estacion.marca.marca + " de la Unidad "+ estacion.responsable.plaza_ocupa.departamento.unidad.nombre+ " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('listar_radio?id=portatil')

# Estaciones Repetidora
@login_required(login_url='/ingresar')
def editar_estacion_repetidora(request):
	perfil = Perfil.objects.get(user=request.session['userid'])
	if perfil.user.is_staff:
		id_equipo = request.GET.get('id')
		equipo=estaciones_repetidoras.objects.get(id=id_equipo)
		if request.method=='POST':
			form_estacion_repetidora = Formulario_Estacion_Repetidora(request.POST,instance=equipo)
			if form_estacion_repetidora.is_valid():
				form = form_estacion_repetidora.save(commit=False)
				form.save()
				acciones='La Estacion Repetidora con marca '+ form.marca.marca + " ubicada en " + form.ubicacion + " fue editada"
				registrar_log(request,acciones,4)
				return render_to_response('estaciones_repetidoras/info_estacion_repetidora.html',{'entity':form,} , context_instance=RequestContext(request))
		else:
			form_estacion_repetidora = Formulario_Estacion_Repetidora(instance=equipo)
		return render_to_response('estaciones_repetidoras/editar_estacion_repetidora.html',{'form_estacion_repetidora':form_estacion_repetidora,'equipo':equipo,} , context_instance=RequestContext(request))
	else:
		return HttpResponseRedirect('/') 

@login_required(login_url='/ingresar')
def agregar_estacion_repetidora(request):
	perfil = Perfil.objects.get(user=request.session['userid'])
	if perfil.user.is_staff:
		id_unidad = request.GET.get('id')
		if request.method=='POST':
			form_estacion_repetidora = Formulario_Estacion_Repetidora(request.POST)
			if form_estacion_repetidora.is_valid():
				form = form_estacion_repetidora.save(commit=False)
				form.save()
				acciones='La Estacion Repetidora con marca '+ form.marca.marca + " ubicada en "+ form.ubicacion + " fue agregado"
				registrar_log(request,acciones,2)
				return render_to_response('estaciones_repetidoras/info_estacion_repetidora.html',{'entity':form} , context_instance=RequestContext(request))
		else:
			form_estacion_repetidora = Formulario_Estacion_Repetidora()
		return render_to_response('estaciones_repetidoras/agregar_estacion_repetidora.html',{'form_estacion_repetidora':form_estacion_repetidora,} , context_instance=RequestContext(request))
	else:
		return HttpResponseRedirect('/') 
@login_required(login_url='/ingresar')
def info_estacion_repetidora(request):
	perfil = Perfil.objects.get(user=request.session['userid'])
	if perfil.user.is_staff:
		id_estacion = request.GET.get('id')
		estacion=estaciones_repetidoras.objects.get(id=id_estacion)
		return render_to_response('estaciones_repetidoras/info_estacion_repetidora.html',{'entity':estacion} , context_instance=RequestContext(request))
	else:
		return HttpResponseRedirect('/') 
		
@login_required(login_url='/ingresar')
def borrar_estacion_repetidora(request):
	perfil = Perfil.objects.get(user=request.session['userid'])
	if perfil.user.is_staff:
		id_estacion = request.GET.get('id')
		estacion=estaciones_repetidoras.objects.get(id=id_estacion)
		estacion.delete()
		acciones='La Estacion Repetidora con marca ' + estacion.marca.marca + " con modelo " + estacion.modelo + " ubicada en " + estacion.ubicacion + " fue eliminada"
		registrar_log(request,acciones,3)
		return HttpResponseRedirect('listar_radio?id=repetidora')
	else:
		return HttpResponseRedirect('/') 
