from django.forms import *
from django import forms
from carpeta.models import *


class Formulario_Documentos(ModelForm):
	class Meta:
		model = Documentos
		exclude=('unidad','documento,')
		widgets = {
			
			
			}

class Formulario_Enlace(ModelForm):
	class Meta:
		model = Enlaces
		exclude=('conectividad', 'ip',)
		widgets = {
			'Tipo de Enlace': TextInput(attrs={'class' :'form-control','placeholder': 'Tipo de Enlace','required':'true'}),
			'Ancho de Banda': Select(attrs={'class' :'select2','placeholder': 'Ancho de banda','required':'true'}),
			'Acceso a Internet': CheckboxInput(attrs={'placeholder': 'Internet'}),
			'Servicio a Pacientes Extranjeros': CheckboxInput(attrs={'placeholder': 'Pacientes extranjeros'}),
			}

class Formulario_Web(ModelForm):
	class Meta:
		model = P_web
		exclude=('conectividad',)
		widgets = {
			'Direccion	': TextInput(attrs={"class" :'form-control','placeholder': 'Direccion','required':'true'}),
			'Tipo': Select(attrs={"class" :"select2",'placeholder': 'Tipo','required':'true'}),
			'Observaciones': Textarea(attrs={"class":"form-control", "rows":"6", "cols":"30", "maxlength":"140", 'placeholder': 'Observaciones'}),
			
			}
			
			
class Formulario_Aplicacion(ModelForm):
	class Meta:
		model = Aplicaciones
		exclude=('estado',)
		widgets = {
			'Nombre	': TextInput(attrs={"class" :'form-control','placeholder': 'Nombre de la Aplicacion','required':'true'}),
			'Comentario': Textarea(attrs={"class":"form-control", "rows":"6", "cols":"30", "maxlength":"140", 'placeholder': 'Comentario'}),
			'Unidad	': TextInput(attrs={"class" :'form-control','placeholder': 'Nombre de la Aplicacion','required':'true'}),
			}

class Formulario_Conectividad(ModelForm):
	class Meta:
		model = Conectividad
		exclude=('unidad',)
		widgets = {
			'Cuentas': NumberInput(attrs={"class" :'form-control','placeholder': 'cuentas','required':'true', 'min_value':'1'}),
			
			}