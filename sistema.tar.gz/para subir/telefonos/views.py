from unidad.models import *
from telefonos.models import *
from telefonos.views import *
from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from unidad.views import *
from rrhh.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from unidad.forms import *
from telefonos.forms import  *
from django.db.models import Sum
from django.db.models import Count
#~ from reportlab.pdfgen import canvas
from django.http import HttpResponse
from django.views.generic import UpdateView

@login_required(login_url='/ingresar')
def listar_telefonia(request):
	tab = request.GET.get('id')
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id=id_unidad)
	pizarras1 =  Pizarra.objects.all()
	telefonos_fijos1 =  Telefono_Fijo.objects.all()
	extenciones1 =  Extencion.objects.all()

	pizarras=[]
	telefonos_fijos=[]
	extenciones=[]

	for pizarra in pizarras1:
		if pizarra.departamento.unidad==unidad:
			pizarras.append(pizarra)

	for telefono in telefonos_fijos1:
		if telefono.departamento.unidad==unidad:
			telefonos_fijos.append(telefono)

	for extencion in extenciones1:
		if extencion.departamento.unidad==unidad:
			extenciones.append(extencion)
			
			
	return render_to_response('telefonia/listar_telefonia.html', {'unidad':unidad,'pizarras':pizarras,'telefonos_fijos':telefonos_fijos,'extenciones':extenciones,'tab':tab}, context_instance=RequestContext(request))

# Pizarras
@login_required(login_url='/ingresar')
def editar_pizarra(request):
	id_pizarra = request.GET.get('id')
	pizarra=Pizarra.objects.get(id=id_pizarra)
	departamentos = Departamento.objects.filter(unidad=pizarra.departamento.unidad) 
	permiso=comprobar_perfil(request,pizarra.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/') 
	if request.method=='POST':
		form_pizarra = Formulario_Pizarra(request.POST,instance=pizarra)
		if form_pizarra.is_valid():
			form = form_pizarra.save(commit=False)
			form.save()
			acciones='La Pizarra con numero '+ form.numero + " del departamento "+ form.departamento.nombre+ " de la Unidad "+ form.departamento.unidad.nombre+ " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('pizarras/info_pizarra.html',{'entity':form,'editar':permiso,} , context_instance=RequestContext(request))
	else:
		form_pizarra = Formulario_Pizarra(instance=pizarra)
	return render_to_response('pizarras/editar_pizarra.html',{'form_pizarra':form_pizarra,'departamentos':departamentos,'pizarra':pizarra,} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def agregar_pizarra(request):
	id_unidad = request.GET.get('id')
	departamentos = Departamento.objects.filter(unidad=id_unidad)  
	if request.method=='POST':
		form_pizarra = Formulario_Pizarra(request.POST)
		if form_pizarra.is_valid():
			form = form_pizarra.save(commit=False)
			form.save()
			acciones='La Pizarra con el numero '+ form.numero + " del departamento "+ form.departamento.nombre+ " de la Unidad "+ form.departamento.unidad.nombre+ " fue agregada"
			registrar_log(request,acciones,2)
			edita=1
			return render_to_response('pizarras/info_pizarra.html',{'entity':form,'editar':edita} , context_instance=RequestContext(request))
	else:
		form_pizarra = Formulario_Pizarra()
	return render_to_response('pizarras/agregar_pizarra.html',{'form_pizarra':form_pizarra,'departamentos':departamentos,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_pizarra(request):
	id_pizarra = request.GET.get('id')
	pizarra=Pizarra.objects.get(id=id_pizarra)
	id_unidad=pizarra.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('pizarras/info_pizarra.html',{'unidad':unidad[0],'editar':permiso,'entity':pizarra} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_pizarra(request):
	id_pizarra = request.GET.get('id')
	pizarra=Pizarra.objects.get(id=id_pizarra)
	id_unidad=pizarra.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	#~ pizarra.delete()
	#~ acciones='La Pizarra con numero '+ pizarra.numero + " de marca " + pizarra.marca + " con modelo " + pizarra.modelo + " del departamento "+ pizarra.departamento.nombre+ " fue eliminada"
	#~ registrar_log(request,acciones,3)
		
	try:	
		pizarra.delete()
		acciones='La Pizarra con numero '+ pizarra.numero + " de marca " + pizarra.marca + " con modelo " + pizarra.modelo + " del departamento "+ pizarra.departamento.nombre+ " fue eliminada"
		registrar_log(request,acciones,3)
		#~ return HttpResponseRedirect('listar_telefonia?id=pizarra')
	except:
		error = 'No se puede eliminar esta pizarra'
		print error
		return HttpResponseRedirect('listar_telefonia?id=pizarra')
		#~ return render_to_response('listar_telefonia?id=pizarra',{'error':error,} , context_instance=RequestContext(request))

	return HttpResponseRedirect('listar_telefonia?id=pizarra')
	

# Telefonos
@login_required(login_url='/ingresar')
def editar_telefono(request):
	id_telefono = request.GET.get('id')
	telefono=Telefono_Fijo.objects.get(id=id_telefono)
	departamentos = Departamento.objects.filter(unidad=telefono.departamento.unidad) 
	permiso=comprobar_perfil(request,telefono.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/') 
	if request.method=='POST':
		form_telefono = Formulario_Telefono_Fijo(request.POST,instance=telefono)
		if form_telefono.is_valid():
			form = form_telefono.save(commit=False)
			form.save()
			acciones='El telefono con numero '+ form.numero + " del departamento "+ form.departamento.nombre+ " de la Unidad "+ form.departamento.unidad.nombre+ " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('telefonos/info_telefono.html',{'entity':form,'editar':permiso,} , context_instance=RequestContext(request))
	else:
		form_telefono = Formulario_Telefono_Fijo(instance=telefono)
	return render_to_response('telefonos/editar_telefono.html',{'form_telefono':form_telefono,'departamentos':departamentos,'telefono':telefono,} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def agregar_telefono(request):
	id_unidad = request.GET.get('id')
	departamentos = Departamento.objects.filter(unidad=id_unidad)  
	if request.method=='POST':
		form_telefono = Formulario_Telefono_Fijo(request.POST)
		if form_telefono.is_valid():
			form = form_telefono.save(commit=False)
			form.save()
			acciones='El telefono con el numero '+ form.numero + " del departamento "+ form.departamento.nombre+ " de la Unidad "+ form.departamento.unidad.nombre+ " fue agregado"
			registrar_log(request,acciones,2)
			edita=1
			return render_to_response('telefonos/info_telefono.html',{'entity':form,'editar':edita} , context_instance=RequestContext(request))
	else:
		form_telefono = Formulario_Telefono_Fijo()
	return render_to_response('telefonos/agregar_telefono.html',{'form_telefono':form_telefono,'departamentos':departamentos,} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_telefono(request):
	id_telefono = request.GET.get('id')
	telefono=Telefono_Fijo.objects.get(id=id_telefono)
	id_unidad=telefono.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('telefonos/info_telefono.html',{'unidad':unidad[0],'editar':permiso,'entity':telefono} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_telefono(request):
	id_telefono = request.GET.get('id')
	telefono=Telefono_Fijo.objects.get(id=id_telefono)
	id_unidad=telefono.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	telefono.delete()
	acciones='El telefono con numero '+ telefono.numero + " del departamento "+ telefono.departamento.nombre+ " fue eliminado"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('listar_telefonia?id=telefono')
	

# Extenciones
@login_required(login_url='/ingresar')
def editar_extencion(request):
	id_extencion = request.GET.get('id')
	extencion=Extencion.objects.get(id=id_extencion)
	id_pizarra = request.GET.get('p')
	pizarra = Pizarra.objects.get(id=id_pizarra)
	departamentos = Departamento.objects.filter(unidad=extencion.departamento.unidad) 
	permiso=comprobar_perfil(request,extencion.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/') 
	if request.method=='POST':
		form_extencion = Formulario_Extencion(request.POST,instance=extencion)
		if form_extencion.is_valid():
			form = form_extencion.save(commit=False)
			form.pizarra = pizarra
			form.save()
			acciones='La extencion con numero '+ form.numero + " del departamento "+ form.departamento.nombre+ " de la Unidad "+ form.departamento.unidad.nombre+ " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('extenciones/info_extencion.html',{'entity':form,'editar':permiso,} , context_instance=RequestContext(request))
	else:
		form_extencion = Formulario_Extencion(instance=extencion)
	return render_to_response('extenciones/editar_extencion.html',{'form_extencion':form_extencion,'departamentos':departamentos,'extencion':extencion,'pizarra':pizarra} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def agregar_extencion(request):
	id_unidad = request.GET.get('id')
	departamentos = Departamento.objects.filter(unidad=id_unidad)
	id_pizarra = request.GET.get('p')
	pizarra = Pizarra.objects.get(id=id_pizarra)
	extenciones = Extencion.objects.all() 
	if request.method=='POST':
		form_extencion = Formulario_Extencion(request.POST)
		if form_extencion.is_valid():
			form = form_extencion.save(commit=False)
			form.pizarra = pizarra
			form.save()
			acciones='La extencion con el numero '+ form.numero + " del departamento "+ form.departamento.nombre+ " de la Unidad "+ form.departamento.unidad.nombre+ " fue agregada"
			registrar_log(request,acciones,2)
			edita=1
			return render_to_response('extenciones/info_extencion.html',{'entity':form,'editar':edita} , context_instance=RequestContext(request))
	else:
		form_extencion = Formulario_Extencion()
	return render_to_response('extenciones/agregar_extencion.html',{'pizarra':pizarra,'form_extencion':form_extencion,'departamentos':departamentos,'extenciones':extenciones} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_extencion(request):
	id_extencion = request.GET.get('id')
	extencion=Extencion.objects.get(id=id_extencion)
	id_unidad=extencion.departamento.unidad.id
	id_pizarra = request.GET.get('p')
	pizarra = Pizarra.objects.get(id=id_pizarra)
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('extenciones/info_extencion.html',{'unidad':unidad[0],'pizarra':pizarra,'editar':permiso,'entity':extencion} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_extencion(request):
	id_extencion = request.GET.get('id')
	extencion=Extencion.objects.get(id=id_extencion)
	id_unidad=extencion.departamento.unidad.id
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	extencion.delete()
	acciones='La Extencion con numero '+ extencion.numero + " del departamento "+ extencion.departamento.nombre+ " fue eliminada"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('listar_telefonia?id=extencion')
	
