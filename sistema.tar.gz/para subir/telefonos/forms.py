from django.forms import *
from django import forms
from telefonos.models import *

class Formulario_Pizarra(ModelForm):
	class Meta:
		model = Pizarra
		widgets = {
			'departamento': Select(attrs={'class' :'select2',}),
			'numero': TextInput(attrs={'class' :'form-control'}),
			'troncos': TextInput(attrs={'class' :'form-control'}),
			'marca': TextInput(attrs={'class' :'form-control'}),
			'modelo': TextInput(attrs={'class' :'form-control'}),
			}


class Formulario_Telefono_Fijo(ModelForm):
	class Meta:
		model = Telefono_Fijo
		widgets = {
			'departamento': Select(attrs={'class' :'select2',}),
			'numero': TextInput(attrs={'class' :'form-control'}),
			}
			
			
class Formulario_Extencion(ModelForm):
	class Meta:
		model = Extencion
		exclude = ('pizarra',)
		widgets = {
			'departamento': Select(attrs={'class' :'select2',}),
			#~ 'pizarra': TextInput(attrs={'class' :'form-control'}),
			'numero': TextInput(attrs={'class' :'form-control'}),
			}			
