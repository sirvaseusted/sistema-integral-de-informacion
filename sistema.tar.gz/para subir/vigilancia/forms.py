from django.forms import *
from django import forms
from vigilancia.models import *


class formulario_centroscerrados(ModelForm):
	class Meta:
		model = centroscerrados
		widgets = {
		'nombre':TextInput(attrs={'class' :'form-control','placeholder': 'Nombre del Centro','required':'false'}),
		'organismo':TextInput(attrs={'class' :'form-control','placeholder': 'Organismo','required':'false'}),
		'direccion':TextInput(attrs={'class' :'form-control','placeholder': 'Direccion','required':'false'}),
		}

class formulario_centrospositivos(ModelForm):
	class Meta:
		model = centrospositivos
		widgets = {
		'nombre':TextInput(attrs={'class' :'form-control','placeholder': 'Nombre del Centro','required':'false'}),
		'organismo':TextInput(attrs={'class' :'form-control','placeholder': 'Organismo','required':'false'}),
		'direccion':TextInput(attrs={'class' :'form-control','placeholder': 'Direccion','required':'false'}),
		'depositos':TextInput(attrs={'class' :'form-control','placeholder': 'Depositos','required':'false'}),
		'clasificacion':TextInput(attrs={'class' :'form-control','placeholder': 'Clasificacion','required':'false'}),
		}
		
		
class formulario_recursos(ModelForm):
	class Meta:
		model = recursos
		widgets = {
		'rrhhhombres':TextInput(attrs={'class' :'form-control','placeholder': 'Total de Hombres','required':'false'}),
		'rrhhhombrestrabajando':TextInput(attrs={'class' :'form-control','placeholder': 'Total de Hombres Trabajando','required':'false'}),
		'equipostotal':TextInput(attrs={'class' :'form-control','placeholder': 'Total de Equipos','required':'false'}),
		'equipostrabajando':TextInput(attrs={'class' :'form-control','placeholder': 'Equipos Trabajando','required':'false'}),
		'equiposnosalieron':TextInput(attrs={'class' :'form-control','placeholder': 'Equipos que No salieron','required':'false'}),
		'equiposrotos':TextInput(attrs={'class' :'form-control','placeholder': 'Equipos Rotos','required':'false'}),
		}
		
		
	
		
		
		
class formulario_tratamientoadulticida(ModelForm):
	class Meta:
		model = tratamientoadulticida

		widgets = {
		'plandiario':TextInput(attrs={'class' :'form-control','placeholder': 'Plan Diario','required':'false'}),
		'tratadas':TextInput(attrs={'class' :'form-control','placeholder': 'Tratadas','required':'false'}),
		'cerrados':TextInput(attrs={'class' :'form-control','placeholder': 'Cerradas','required':'false'}),
		'manzanasuniverso':TextInput(attrs={'class' :'form-control','placeholder': 'Universo de Manzanas','required':'false'}),
		'manzanastratadas':TextInput(attrs={'class' :'form-control','placeholder': 'Manzanas Tratadas','required':'false'}),
		'localuniverso':TextInput(attrs={'class' :'form-control','placeholder': 'Universo Locales','required':'false'}),
		'localratados':TextInput(attrs={'class' :'form-control','placeholder': 'Universo Tratados','required':'false'}),
		'localcerradas':TextInput(attrs={'class' :'form-control','placeholder': 'Universo Cerrados','required':'false'}),
		}
		








class formulario_tratamientofocal(ModelForm):
	class Meta:
		model = tratamientofocal
		exclude=('localpoindcasa','localpoindbetau',)
		widgets = {
		'depoinspecciondos':TextInput(attrs={'class' :'form-control','placeholder': 'Locales Inspeccionados','required':'false'}),
		'depocerrados':TextInput(attrs={'class' :'form-control','placeholder': 'Locales Cerrados','required':'false'}),
		'depositostotal':TextInput(attrs={'class' :'form-control','placeholder': 'Depositos Totales','required':'false'}),
		'depositospositivos':TextInput(attrs={'class' :'form-control','placeholder': 'Depositos Positivos','required':'false'}),
		'innainspeccionados':TextInput(attrs={'class' :'form-control','placeholder': 'Inaccesibles Inspeccionados','required':'false'}),
		'innaexistentes':TextInput(attrs={'class' :'form-control','placeholder': 'Inaccesibles Existentes','required':'false'}),
		'localpoadultos':TextInput(attrs={'class' :'form-control','placeholder': 'Inaccesibles Inspeccionados','required':'false'}),
		'localpolarv':TextInput(attrs={'class' :'form-control','placeholder': 'Local Positivo Adultos','required':'false'}),
		}



class formulario_universotratamientoadulticida(ModelForm):
	class Meta:
		model = universotratamientoadulticida

class formulario_universotratamientofocal(ModelForm):
	class Meta:
		model = universotratamientofocal

class formulario_albopictus(ModelForm):
	class Meta:
		model = albopictus
		exclude=('unidad','actualizacion','fecha',)
		widgets = {
		'focos':TextInput(attrs={'class' :'form-control','placeholder': 'Focos','required':'false'}),
		'tbajo':TextInput(attrs={'class' :'form-control','placeholder': 'Tanques Bajos','required':'false'}),
		'telev':TextInput(attrs={'class' :'form-control','placeholder': 'Tanques Elevados','required':'false'}),
		'ciste':TextInput(attrs={'class' :'form-control','placeholder': 'Cisternas','required':'false'}),
		'a4odep':TextInput(attrs={'class' :'form-control','placeholder': 'A4','required':'false'}),
		'artnodestruible':TextInput(attrs={'class' :'form-control','placeholder': 'Artesanales No Destruibles','required':'false'}),
		'artdestruible':TextInput(attrs={'class' :'form-control','placeholder': 'Artesanales Destruibles','required':'false'}),
		'naturales':TextInput(attrs={'class' :'form-control','placeholder': 'Naturales','required':'false'}),
		'eresliq':TextInput(attrs={'class' :'form-control','placeholder': 'Residuos L','required':'false'}),
		'depvigi':TextInput(attrs={'class' :'form-control','placeholder': 'Depositos Vigilancia','required':'false'}),
		'adultos':TextInput(attrs={'class' :'form-control','placeholder': 'Adultos','required':'false'}),
		}

class formulario_centrospriorizados(ModelForm):
	class Meta:
		model = centrospriorizados
		exclude=('unidad','actualizacion','fecha',)
		widgets = {
		'ciplan':TextInput(attrs={'class' :'form-control','placeholder': 'Centros Inspeccionados Plan','required':'false'}),
		'cireal':TextInput(attrs={'class' :'form-control','placeholder': 'Centros Inspeccionados Real','required':'false'}),
		'larvitrampasinstaladas':TextInput(attrs={'class' :'form-control','placeholder': 'Larvitrampas Instaladas','required':'false'}),
		'larvitrampaspositivas':TextInput(attrs={'class' :'form-control','placeholder': 'Larvitrampas Positivas','required':'false'}),
		'epaaeg':TextInput(attrs={'class' :'form-control','placeholder': 'Especie Predominante Aedes Aegipti','required':'false'}),
		'epaalb':TextInput(attrs={'class' :'form-control','placeholder': 'Especie Predominante Aedes Albupico','required':'false'}),
		'epatan':TextInput(attrs={'class' :'form-control','placeholder': 'Especie Predominante Aedes Taen.','required':'false'}),
		'epaalbm':TextInput(attrs={'class' :'form-control','placeholder': 'Especie Predominante Aedes Almbom','required':'false'}),
		'epoe':TextInput(attrs={'class' :'form-control','placeholder': 'Otras Especies predominantes','required':'false'}),
		'otros':TextInput(attrs={'class' :'form-control','placeholder': 'Otros Vectores','required':'false'}),
		'moscas':TextInput(attrs={'class' :'form-control','placeholder': 'Moscas','required':'false'}),
		'cucarachas':TextInput(attrs={'class' :'form-control','placeholder': 'Cucarachas','required':'false'}),
		'roedores':TextInput(attrs={'class' :'form-control','placeholder': 'Roedores','required':'false'}),
		'larvasgeneral':TextInput(attrs={'class' :'form-control','placeholder': 'Larvas general','required':'false'}),
		'adulreposo':TextInput(attrs={'class' :'form-control','placeholder': 'Adultos en Reposo','required':'false'}),
		'encebohumano':TextInput(attrs={'class' :'form-control','placeholder': 'En Cebo Humano','required':'false'}),
		}
