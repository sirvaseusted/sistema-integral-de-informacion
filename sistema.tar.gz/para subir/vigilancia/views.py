from django.shortcuts import render
from datetime import *

# Create your views here.
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from vigilancia.models import *
from unidad.views import *
from rrhh.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest, HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required

from vigilancia.forms import formulario_centroscerrados, formulario_centrospositivos, formulario_recursos, formulario_tratamientoadulticida, formulario_tratamientofocal, formulario_universotratamientoadulticida, formulario_universotratamientofocal, formulario_albopictus, formulario_centrospriorizados
from django.db.models import Sum
from django.db.models import Count


from django.views.generic import UpdateView
#~ 
#~ from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Table, TableStyle,PageBreak
#~ from reportlab.lib.styles import getSampleStyleSheet
#~ from reportlab.lib import colors
#~ from reportlab.lib.pagesizes import letter, inch, landscape, portrait
#~ from reportlab.lib.enums import TA_CENTER
from django.utils.translation import string_concat
from django.views.generic import UpdateView, ListView
from io import BytesIO








@login_required(login_url='/ingresar')
def agregar_centroscerrados(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)

	if request.method=='POST':
		form_centroscerrados = formulario_centroscerrados(request.POST, request.FILES)
		
		if form_centroscerrados.is_valid():
			form = form_centroscerrados.save(commit=False)
			form.unidad_id = int(unidadid)
			form.save()
			ccerrados = centroscerrados.objects.filter(unidad=unidadid)
	
			return render_to_response('informes/index.centroscerrados.html',{'entity':form, 'ccerrados':ccerrados} , context_instance=RequestContext(request))
		else:
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			unidad= new_plaza.departamento.unidad
	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_centroscerrados = formulario_centroscerrados()

	return render_to_response('informes/formulario.centroscerrados.html',{'form_centroscerrados':form_centroscerrados,'unidad':unidad} , context_instance=RequestContext(request))




@login_required(login_url='/ingresar')
def info_centroscerrados(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	ccerrados = centroscerrados.objects.filter(unidad=unidadid).order_by('-id')
	
	return render_to_response('informes/index.centroscerrados.html',{'ccerrados':ccerrados, 'unidad':unidad} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def borrar_centroscerrados(request):
	id_registro = request.GET.get('registro')
	registro=centroscerrados.objects.get(id=id_registro)
	registro.delete()
	return HttpResponseRedirect('/info_centroscerrados')







@login_required(login_url='/ingresar')
def info_centrospositivos(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	cpositivos = centrospositivos.objects.filter(unidad=unidadid)

	return render_to_response('informes/index.centrospositivos.html',{'cpositivos':cpositivos, 'unidad':unidad} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def agregar_centrospositivos(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)

	if request.method=='POST':
		form_centrospositivos = formulario_centrospositivos(request.POST, request.FILES)
		
		if form_centrospositivos.is_valid():
			form = form_centrospositivos.save(commit=False)
			form.unidad_id = int(unidadid)
			form.save()
			
			cpositivos = centrospositivos.objects.filter(unidad=unidadid)
			
			return render_to_response('informes/index.centrospositivos.html',{'entity':form, 'cpositivos':cpositivos} , context_instance=RequestContext(request))
		else:
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			unidad= new_plaza.departamento.unidad
	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_centrospositivos = formulario_centrospositivos()
	return render_to_response('informes/formulario.centrospositivos.html',{'form_centrospositivos':form_centrospositivos,'unidad':unidad} , context_instance=RequestContext(request))




@login_required(login_url='/ingresar')
def borrar_centrospositivos(request):
	id_registro = request.GET.get('registro')
	registro=centrospositivos.objects.get(id=id_registro)
	registro.delete()
	return HttpResponseRedirect('/info_centrospositivos')














@login_required(login_url='/ingresar')
def info_recursos(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	recur = recursos.objects.filter(unidad=unidadid)

	return render_to_response('informes/index.recursos.html',{'recur':recur, 'unidad':unidad} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def agregar_recursos(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)

	if request.method=='POST':
		form_recursos = formulario_recursos(request.POST, request.FILES)
		
		if form_recursos.is_valid():
			form = form_recursos.save(commit=False)
			form.unidad_id = int(unidadid)
			form.save()
			
			recur = recursos.objects.filter(unidad=unidadid)
			
			return render_to_response('informes/index.recursos.html',{'entity':form, 'recur':recur} , context_instance=RequestContext(request))
		else:
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			unidad= new_plaza.departamento.unidad
	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_recursos = formulario_recursos()
	return render_to_response('informes/formulario.recursos.html',{'form_recursos':form_recursos,'unidad':unidad} , context_instance=RequestContext(request))




@login_required(login_url='/ingresar')
def borrar_recursos(request):
	id_registro = request.GET.get('registro')
	recur = recursos.objects.get(id=id_registro)
	recur.delete()
	return HttpResponseRedirect('/info_recursos')











@login_required(login_url='/ingresar')
def info_tratamientoadulticida(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	adulticida = tratamientoadulticida.objects.filter(unidad=unidadid)

	return render_to_response('informes/index.adulticida.html',{'adulticida':adulticida, 'unidad':unidad} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def agregar_tratamientoadulticida(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)

	univers= universotratamientoadulticida.objects.get(unidad=unidadid)

	if request.method=='POST':
		form_tratamientoadulticida = formulario_tratamientoadulticida(request.POST, request.FILES)
		
		if form_tratamientoadulticida.is_valid():
			form = form_tratamientoadulticida.save(commit=False)
			form.unidad_id = int(unidadid)
			form.universo_id = int(univers.id)
			

			
			form.save()
			
			adulticida = tratamientoadulticida.objects.filter(unidad=unidadid)
			
			return render_to_response('informes/index.adulticida.html',{'entity':form, 'adulticida':adulticida} , context_instance=RequestContext(request))
		else:
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			unidad= new_plaza.departamento.unidad
	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_tratamientoadulticida = formulario_tratamientoadulticida()
	return render_to_response('informes/formulario.adulticida.html',{'form_tratamientoadulticida':form_tratamientoadulticida,'unidad':unidad} , context_instance=RequestContext(request))




@login_required(login_url='/ingresar')
def borrar_tratamientoadulticida(request):
	id_registro = request.GET.get('registro')
	adulticida = tratamientoadulticida.objects.get(id=id_registro)
	adulticida.delete()
	return HttpResponseRedirect('/info_tratamientoadulticida')







@login_required(login_url='/ingresar')
def info_tratamientofocal(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	focal = tratamientofocal.objects.filter(unidad=unidadid).order_by('actualizacion')

	return render_to_response('informes/index.focal.html',{'focal':focal, 'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def agregar_tratamientofocal(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	univers= universotratamientofocal.objects.get(unidad=unidadid)
	
	
	if request.method=='POST':
		form_tratamientofocal = formulario_tratamientofocal(request.POST, request.FILES)
		
		if form_tratamientofocal.is_valid():
			form = form_tratamientofocal.save(commit=False)
			form.unidad_id = int(unidadid)
			form.universo_id = int(univers.id)

			form.localpoindcasa = round((float(form.localpolarv) + float(form.localpoadultos)) / float(form.depoinspecciondos)*float(100.), 4)

			form.localpoindbetau = round(float(form.depositospositivos)/float(form.depositostotal)*float(100.), 4)

			form.localpototal = float(form.localpolarv) + float(form.localpoadultos)
			form.save()
			
			focal = tratamientofocal.objects.filter(unidad=unidadid).order_by('actualizacion')
			
			return render_to_response('informes/index.focal.html',{'entity':form, 'focal':focal} , context_instance=RequestContext(request))
		else:
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			unidad= new_plaza.departamento.unidad
	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_tratamientofocal = formulario_tratamientofocal()
	return render_to_response('informes/formulario.focal.html',{'form_tratamientofocal':form_tratamientofocal,'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_tratamientofocal(request):
	id_registro = request.GET.get('registro')
	focal = tratamientofocal.objects.get(id=id_registro)
	focal.delete()
	return HttpResponseRedirect('/info_tratamientofocal')














@login_required(login_url='/ingresar')
def info_albopictus(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	albo = albopictus.objects.filter(unidad=unidadid).order_by('fecha')

	return render_to_response('informes/index.albopictus.html',{'albo':albo, 'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def agregar_albopictus(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)

	if request.method=='POST':
		form_albopictus = formulario_albopictus(request.POST, request.FILES)
		
		if form_albopictus.is_valid():
			fecha = request.POST.get('fecha')

			form = form_albopictus.save(commit=False)
			form.unidad_id = int(unidadid)
			form.fecha = fecha
			form.save()
			albo = albopictus.objects.filter(unidad=unidadid).order_by('fecha')
			return render_to_response('informes/index.albopictus.html',{'entity':form, 'albo':albo} , context_instance=RequestContext(request))

	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_albopictus = formulario_albopictus()
	return render_to_response('informes/formulario.albopictus.html',{'form_albopictus':form_albopictus,'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_albopictus(request):
	id_registro = request.GET.get('registro')
	albo = albopictus.objects.get(id=id_registro)
	albo.delete()
	return HttpResponseRedirect('/info_albopictus')







@login_required(login_url='/ingresar')
def info_centrospriorizados(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)
	cenpri = centrospriorizados.objects.filter(unidad=unidadid).order_by('fecha')

	return render_to_response('informes/index.centrospriorizados.html',{'cenpri':cenpri, 'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def agregar_centrospriorizados(request):
	unidadid=request.session['unidad']
	unidad=Unidad.objects.get(id=unidadid)

	if request.method=='POST':
		form_centrospriorizados = formulario_centrospriorizados(request.POST, request.FILES)
		
		if form_centrospriorizados.is_valid():
			fecha = request.POST.get('fecha')

			form = form_centrospriorizados.save(commit=False)
			form.unidad_id = int(unidadid)
			form.fecha = fecha
			form.save()
			cenpri = centrospriorizados.objects.filter(unidad=unidadid).order_by('fecha')
			return render_to_response('informes/index.centrospriorizados.html',{'entity':form, 'cenpri':cenpri} , context_instance=RequestContext(request))

	else:
		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		form_centrospriorizados = formulario_centrospriorizados()
	return render_to_response('informes/formulario.centrospriorizados.html',{'form_centrospriorizados':form_centrospriorizados,'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_centrospriorizados(request):
	id_registro = request.GET.get('registro')
	cenpri = centrospriorizados.objects.get(id=id_registro)
	cenpri.delete()
	return HttpResponseRedirect('/info_centrospriorizados')



