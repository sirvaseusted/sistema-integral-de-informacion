from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from transporte.models import *

from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from transporte.forms import  *
from django.db.models import Sum
from django.db.models import Count
#~ from qrcode import *



@login_required(login_url='/ingresar')
def transporte(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Transporte':

		id_unidad=request.session['unidad']
		unidad= Unidad.objects.get(id=id_unidad)
		transporte = parque.objects.filter(unidad=unidad)

		for t in transporte:
			qr = QRCode(version=2, error_correction=ERROR_CORRECT_L)
			datos = 'Matricula: ' + t.matricula + '\nSerie de carroceria: ' + t.serie + '\nSerie del Motor: ' + t.motor
			qr.add_data(datos)
			qr.make()
			im = qr.make_image()
			im.save('/var/www/pro/sii/qrtransporte/' + t.matricula + ".png")



		return render_to_response('transporte/transporte.html',{
		'transporte':transporte,
		'unidad':unidad,
		}, context_instance=RequestContext(request))

	else:
		return HttpResponseRedirect('/')

@login_required(login_url='/ingresar')
def docsubordinados(request):

	id_unidad = request.GET.get('id')
	unidad= Unidad.objects.get(id=id_unidad)
#documentos oficiales solicitados
	document = Ficheros.objects.filter(unidad=request.session['unidad'])
#documentos oficiales subidos por el usuario
	fichero = Documentos.objects.filter(documento=document, unidad = id_unidad)
	files = []
	for file in fichero: 
		files.append(file.documento)

	return render_to_response('transporte/documentos_subordinados.html',{
	'document':document, 
	'fichero':fichero, 
	'files':files,
	'id_unidad':id_unidad,
	'unidad':unidad 
	}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def form_auto(request):
	id_unidad = request.session['unidad']
	unidad = Unidad.objects.get(id = id_unidad)

	organizativa = request.session['organizativa']
	if organizativa == 'Transporte':

		#~ id_auto = request.GET.get('id_auto')
		#~ id_unidad = request.GET.get('id_unidad')
		#~ permiso=comprobar_perfil(request,id_unidad)
		#~ if permiso == 2 or permiso == 0:
			#~ return HttpResponseRedirect('/')
		if request.method=='POST':

			fficav = request.POST.get('ficav')
			fcirculacion = request.POST.get('circulacion')
			foperativa = request.POST.get('operativa')
			datos=""
			form_parque = formulario_parque(request.POST, request.FILES)
			if form_parque.is_valid():
				form = form_parque.save(commit=False)
				form.unidad=unidad
				
				datos = form.matricula
				
				form.ficav = fficav
				form.circulacion = fcirculacion
				form.operativa = foperativa


				qr = QRCode(version=1, error_correction=ERROR_CORRECT_L)
				qr.add_data(datos)
				qr.make()
				im = qr.make_image()
				im.save('/var/www/pro/sii/qrtransporte/' + form.matricula + ".png")

				#form.imagen = (form.matricula + ".png")

				form.save()
				form_parque.save_m2m()


				return HttpResponseRedirect('/transporte')

				#~ acciones='El vehiculo '+ str(form.matricula) + " fue agregado a la unidad "+ str(form.unidad)
				#~ registrar_log(request,acciones,2)
				#~ if str(form.unidad.id) == str(request.session['unidad']):
					#~ return HttpResponseRedirect('/transporte')
				#~ else:
					#~ return HttpResponseRedirect('/docsubordinados?id='+id_unidad)
		else:
			form_parque = formulario_parque()
		return render_to_response('transporte/formulario.transporte.html',{'form_parque':form_parque} , context_instance=RequestContext(request))

	else:
		return HttpResponseRedirect('/')

@login_required(login_url='/ingresar')
def form_editar_auto(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Transporte':

		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		#~ # me quede por aki... arreglar esto
		id_auto = request.GET.get('id_auto')
		auto = parque.objects.get(id=id_auto)
		#fichero.delete()
		#~ document = Ficheros.objects.filter(unidad=request.session['unidad'])
		#~ permiso=comprobar_perfil(request,id_unidad)
		#~ if permiso == 2 or permiso == 0:
			#~ return HttpResponseRedirect('/')
		if request.method=='POST':

			fficav = request.POST.get('ficav')
			fcirculacion = request.POST.get('circulacion')
			foperativa = request.POST.get('operativa')
			datos=""

			form_parque = formulario_parque(request.POST, request.FILES, instance=auto)
			if form_parque.is_valid():
				form = form_parque.save(commit=False)
				form.ficav = fficav
				form.circulacion = fcirculacion
				form.operativa = foperativa
				datos = form.matricula

				qr = QRCode(version=1, error_correction=ERROR_CORRECT_L)
				qr.add_data(datos)
				qr.make()
				im = qr.make_image()
				im.save('/var/www/pro/sii/qrtransporte/' + form.matricula + ".png")

				#form.imagen = (form.matricula + ".png")


				form.save()
				form_parque.save_m2m()

				#~ acciones='El Documento '+ form.documento.nombre + " fue agregado a la unidad "+ form.unidad.nombre + "de" + form.unidad.municipio.municipio
				#~ registrar_log(request,acciones,4)
				return HttpResponseRedirect('/transporte')
		else:
			form_parque = formulario_parque(instance=auto)
		return render_to_response('transporte/formulario.transporte.html',{'form_parque':form_parque, 'auto':auto, 'unidad':unidad} , context_instance=RequestContext(request))


	else:
		return HttpResponseRedirect('/')

@login_required(login_url='/ingresar')
def eliminar_auto(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Transporte':

		id_auto = request.GET.get('id_auto')
		auto = parque.objects.get(id=id_auto)
		auto.delete()

		return HttpResponseRedirect('/transporte')



	else:
		return HttpResponseRedirect('/')

@login_required(login_url='/ingresar')
def info_auto(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Transporte':

		id_unidad = request.session['unidad']
		unidad= Unidad.objects.get(id=id_unidad)
		id_transporte = request.GET.get('id')
		auto=parque.objects.get(id=id_transporte)
		#~ permiso=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
		#~ if permiso ==2:
			#~ return HttpResponseRedirect('/')
		#~ editar=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
		return render_to_response('transporte/info.transporte.html',{'entity':auto, 'unidad':unidad} , context_instance=RequestContext(request))



	else:
		return HttpResponseRedirect('/')

