from django.forms import *
from django import forms
from tareas.models import *
from rrhh.models import *


class Formulario_Tareas(ModelForm):
	class Meta:
		model = Tarea
		exclude=('activo', 'fini', 'ffin')
		widgets = {
			'tarea': TextInput(attrs={'class' :'form-control','placeholder': 'Tarea'}),
			'descripcion': Textarea(attrs={'class' :'form-control','placeholder': 'Descripcion'}),
			'clasificacion': Select(attrs={'class' :'select2','placeholder': 'Clasificacion'}),
			'prioridad': Select(attrs={'class' :'select2','placeholder': 'Prioridad'}),
			'categoria': Select(attrs={'class' :'select2','placeholder': 'Categoria'}),
			'estado': Select(attrs={'class' :'select2','placeholder': 'Estado'}),
			}

