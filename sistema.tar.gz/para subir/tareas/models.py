from django.db import models
from rrhh.models import *


class Nom_Categoria_Tarea(models.Model):
	categoria = models.CharField('Tipo de Tarea', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length=256, blank=True)

	def __unicode__(self):
		return '%s' % (self.categoria)


class Nom_Clasificacion_Tarea(models.Model):
	clasificacion = models.CharField('Tipo de Tarea', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length=256, blank=True)

	def __unicode__(self):
		return '%s' % (self.clasificacion)


class Nom_Prioridad_Tarea(models.Model):
	prioridad = models.CharField('Tipo de Prioridad', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length=256, blank=True)

	def __unicode__(self):
		return '%s' % (self.prioridad)


class Nom_Estado_Tarea(models.Model):
	estado = models.CharField('Tipo de Estado', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length=256, blank=True)

	def __unicode__(self):
		return '%s' % (self.estado)

class Nom_Frecuencia_Tarea(models.Model):

	nombre = models.CharField('Tipo de Frecuencia', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Estado', max_length=256, blank=True)

	def __unicode__(self):
		return '%s' % (self.estado)


class Tarea(models.Model):
	tarea = models.CharField('Nombre de la Tarea', max_length=256, blank=True, null=True)
	descripcion = models.TextField('Descripcion', max_length=256, blank=True, null=True)

	clasificacion = models.ForeignKey(Nom_Clasificacion_Tarea, max_length=256, blank=True, null=True)
	prioridad = models.ForeignKey(Nom_Prioridad_Tarea, max_length=256, blank=True, null=True)
	estado = models.ForeignKey(Nom_Estado_Tarea, max_length=256, blank=True, null=True)
	categoria = models.ForeignKey(Nom_Categoria_Tarea, max_length=256, blank=True, null=True)

	freg = models.DateField('Fecha de Registro', auto_now=True, auto_now_add=True)
	fini = models.DateTimeField('Fecha de Inicio', auto_now=False, auto_now_add=False)
	ffin = models.DateTimeField('Fecha de Finalizacion', auto_now=False, auto_now_add=False)

	responsable = models.CharField('Responsable', max_length=256, blank=True, null=True)
	participantes = models.ManyToManyField(Trabajador, max_length=256, blank=True, null=True)

	activo = models.BooleanField('Estado', max_length=256, blank=True)

	def __unicode__(self):
		return '%s' % (self.tarea)
