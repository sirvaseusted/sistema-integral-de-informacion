from django.forms import *
from django import forms
from distribucion.models import *


class formulario_movimiento(ModelForm):
	class Meta:
		model = movimiento
		widgets = {
		'tipomovimiento': Select(attrs={"class" :"select2",'placeholder': 'Productos'}),
		'unidad': Select(attrs={"class" :"select2",'placeholder': 'Unidad'}),
		'cantidad': TextInput(attrs={'class' :'form-control','placeholder': 'Cantidad'}),
		'pcosto': TextInput(attrs={'class' :'form-control','placeholder': 'Observaciones'}),
		}


class editar_formulario_movimiento(ModelForm):
	class Meta:
		model = movimiento
		exclude=('mesa','pedido','importe',)
		widgets = {
		'tipomovimiento': Select(attrs={"class" :"select2",'placeholder': 'Productos'}),
		'unidad': Select(attrs={"class" :"select2",'placeholder': 'Unidad'}),
		'cantidad': TextInput(attrs={'type' :'form-control','class' :'form-control','placeholder': 'Cantidad'}),
		'pcosto': TextInput(attrs={'class' :'form-control','placeholder': 'Observaciones'}),
		}
