from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from unidad.models import *
from distribucion.models import *
#~ from almacen.models import *
from distribucion.forms import *

from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q
from django.forms.formsets import formset_factory
from django.forms.formsets import BaseFormSet
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.db.models import Count
import datetime





def inicio(request):
	t = tipomovimiento.objects.all()

	#~ m = movimiento.objects.all()


	today_min = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
	today_max = datetime.datetime.combine(datetime.date.today(), datetime.time.max)

	m = movimiento.objects.filter(actualizacion__range=(today_min, today_max))


	conteoi = tipomovimiento.objects.annotate(imp=Sum('movimiento__importe'))
	conteoc = tipomovimiento.objects.annotate(cos=Sum('movimiento__pcosto'))


	i=[]
	for e in conteoi:
		i= e.imp

	c=[]
	for e in conteoc:
		c= e.cos



	alma = existencia.objects.all()

	return render_to_response('movimiento/inicio.html',{
	'movimiento':m,
	'conteoi':conteoi,
	'conteoc':conteoc,
	'tipo':t,
	'i':i,
	'c':c,
	'almacen':alma,
	}, context_instance=RequestContext(request))



def carta(request):
	productos = producto.objects.filter(activo=True).order_by('-tipo')
	if request.method=='POST':

		id = request.POST.get('id_producto')
		pro = producto.objects.get(id=id)

		t = tipo.objects.filter(id=2)
		form_movimiento = formulario_movimiento(request.POST, request.FILES)
		if form_movimiento.is_valid():

			form = form_movimiento.save(commit=False)
			form.tipo = t[0]

			form.producto = pro
			form.importe = float(pro.pventa) * float(form.cantidad)
			form.pcosto = float(pro.pcosto) * float(form.cantidad)
			
			form.save()
			return HttpResponseRedirect('/carta')
	else:
		form_movimiento = formulario_movimiento()
	return render_to_response('movimiento/carta.html',{
	'form_movimiento':form_movimiento,
	'productos':productos,
	} , context_instance=RequestContext(request))









def listar(request):
	informe = set(movimiento.objects.values_list('pedido', flat=True))

	pro=[]
	for i in informe:
		p = pedido.objects.get(id=i)
		pro.append(p)

	return render_to_response('movimiento/listar.html',{
	'informe':informe,
	'pro':pro,
	}, context_instance=RequestContext(request))




def infopedido(request):

	id_pedido = request.GET.get('id')
	ped = pedido.objects.get(id=id_pedido)
	m = movimiento.objects.filter(pedido=ped)

	#~ t = 0
	#~ for e in m:
		#~ t = t + float(e.importe)

	return render_to_response('movimiento/info.html',{
	#~ 't':t,
	'm':m,
	'ped':ped,
	}, context_instance=RequestContext(request))














def eliminar(request):
	id = request.GET.get('id_movimiento')
	auto = pedido.objects.filter(id=id)
	auto.delete()
	return HttpResponseRedirect('/distribucion')




def agregar(request):
	fmov = formset_factory(formulario_movimiento)
	listamesas = mesa.objects.all()

	unidades = Unidad.objects.filter(subordinacion=request.session['unidad'])



	if request.method=='POST':
		form_movimiento = fmov(request.POST, request.FILES)
		fm = fmov(request.POST)
		fmesa = request.POST.get('mesa')
		fcomentario = request.POST.get('comentario')
		m = mesa.objects.get(id=fmesa)

		a = datetime.datetime.now() 

		ped = pedido(pedido=a, comentario=fcomentario) 
		ped.save()



		if fm.is_valid():


			for instance in fm:
				form = instance.save(commit=False)
				form.pedido = ped
				form.mesa = m
				form.save()


			return HttpResponseRedirect('/distribucion')
	else:
		form_movimiento = fmov()
	return render_to_response('movimiento/agregar.html',{'listamesas':listamesas, 'form_movimiento':form_movimiento, 'unidades':unidades} , context_instance=RequestContext(request))



def editar(request):
	id_equipo = request.GET.get('id')
	auto = movimiento.objects.get(id=id_equipo)

	if request.method=='POST':
		form_calderas = editar_formulario_movimiento(request.POST,instance=auto)
		if form_calderas.is_valid():
			form = form_calderas.save(commit=False)
			form.save()
		return HttpResponseRedirect('/distribucion')

	else:
		form_calderas = editar_formulario_movimiento(instance=auto)
	return render_to_response('movimiento/editar.html',{'form_movimiento':form_calderas} , context_instance=RequestContext(request))

