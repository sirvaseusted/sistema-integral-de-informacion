#!/usr/bin/python
# -*- coding: UTF-8 -*-
from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from rrhh.models import *
from inspeccion.models import *
from carpeta.models import *

from django.http import HttpResponseRedirect, HttpRequest


from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from django.db.models import Sum
from django.db.models import Count

def unidad_enlace(request):
	unidades= Unidad.objects.all()
	
	return render_to_response('unidad_enlace.html',{'unidades':unidades}, context_instance=RequestContext(request))

#~ 
#~ def listado(request):
	#~ u= Perfil.objects.all()
#~ 
	#~ return render_to_response('listado.html',{'u':u}, context_instance=RequestContext(request))
#~ 



#~ 
#~ 
#~ def listado(request):
	#~ u= Unidad.objects.get(id=440)
	#~ 
	#~ unidades= Unidad.objects.filter(subordinacion=u)
	#~ 
	#~ unidadessub2 = []
	#~ for x in unidades:
		#~ unidadessub2.append(Unidad.objects.filter(subordinacion=x))
#~ 
#~ 
	#~ return render_to_response('listado.html',{
	#~ 'u':u,
	#~ 'unidades':unidades,
	#~ 'unidadessub2':unidadessub2,
	#~ }, context_instance=RequestContext(request))
#~ 
#~ 


def listado(request):
	u= Unidad.objects.get(id=1001)
	unidades= Unidad.objects.filter(subordinacion=u)


	unidadessub2 = []
	for x in unidades:
		unidadessub2.append(Unidad.objects.filter(subordinacion=x))






	unidadessub3 = []
	for y in unidadessub2:
		unidadessub3.append(Unidad.objects.filter(subordinacion=y))







	return render_to_response('listado.html',{
	'u':u,
	'unidades':unidades,
	'unidadessub2':unidadessub2,
	'unidadessub3':unidadessub3,
	}, context_instance=RequestContext(request))







def reporte_unidad(request):
	unidades= Unidad.objects.all()
	reporte=[]
	archivos=[]
	lista=[]
	for archivo in Ficheros.objects.all():
		archivos.append(archivo.nombre)
	for entity in unidades:

		trabajadores=Trabajador.objects.filter(plaza_ocupa__departamento__unidad=entity)

		contador=0
		for trabajador in trabajadores:
			if hasattr(trabajador, 'perfil'):
				contador=contador+1
		doc=[]
		for archivo in Ficheros.objects.all():
			doc.append(len(Documentos.objects.filter(documento=archivo,unidad=entity)))

		visit=0
		conectividad = "No"
		pweb = "No"


		fecha = Userlog.objects.filter(unidad = entity.nombre).order_by('-fecha')
		if len(fecha) == 0:
			fecha = "No se ha accedido"
		else:
			fecha = fecha[0].fecha


		if len(entity.conectividades.all())>0:
			conectividad = "Sí"

			for conn in entity.conectividades.all():
				if len(conn.p_web.all())>0:
					pweb = "Sí"


		user = Perfil.objects.filter(trabajador__plaza_ocupa__departamento__unidad=entity)
		for u in user:
			lista.append(u)


		if hasattr(entity, 'visitas'):
			visit=len(entity.visitas.all())
		if user != 0:
			reporte.append({'municipio':entity.municipio,'nombre':entity.nombre,'documento':doc,'realizadas':visit,'hechas':Visita.objects.filter(participantes__in=trabajadores).count(), 'conectividad': conectividad, 'pweb':pweb, 'lista':lista, "ult_fecha": fecha
#			reporte.append({'municipio':entity.municipio,'nombre':entity.nombre,'realizadas':visit,'hechas':Visita.objects.filter(participantes__in=trabajadores).count(), 'conectividad': conectividad, 'pweb':pweb, 'cant_user':cant_user
})
	return render_to_response('reporte_unidad.html',{'unidades':reporte,'archivos':archivos}, context_instance=RequestContext(request))

