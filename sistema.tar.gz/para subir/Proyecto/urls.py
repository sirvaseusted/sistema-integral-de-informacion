from django.conf.urls import patterns, include, url
from django.conf import settings
from unidad import views
from rrhh import views
from tareas import views
from radio import views
from carpeta import views
from equipamiento.forms import *
from equipamiento import views 
from inspeccion import views
from mensajes import views
from reclutamiento import views
from equipamiento.views import ContactWizard
from django.contrib import admin
admin.autodiscover()


from django.conf.urls import *
#~ from wkhtmltopdf.views import PDFTemplateView


from django.conf.urls import handler404
from errores.views import mi_error_404
 
handler404 = mi_error_404








urlpatterns = patterns('',
	url(r'^admin/', include(admin.site.urls)),
	url(r'^Galeria/(?P<path>.*)$','django.views.static.serve', {'document_root':settings.MEDIA_ROOT,}),

	url(r'^$','rrhh.views.inicial'), 
	url(r'^ingresar/$','rrhh.views.ingresar'),
	url(r'^cambiar_clave','rrhh.views.cambiar_clave'),
	url(r'^cerrar_sesion/$', 'rrhh.views.cerrar'),
	#url(r'^pastebin/', include('pastebin.urls')),
	url(r'^info_unidad','unidad.views.info_unidad'), 
	url(r'^unidades_sub_unidad','unidad.views.unidades_sub_unidad'),

#URL PARA MOSTRAR LOS DATOS DE LA UNIDAD PROPIA
	url(r'^lista_unidad','unidad.views.lista_unidad'), 

	url(r'^agregar_unidad','unidad.views.agregar_unidad'), 
	url(r'^form_editar_unidad','unidad.views.form_editar_unidad'), 
	url(r'^borrar_unidad','unidad.views.borrar_unidad'), 

	url(r'^galeria','galeria.views.galeria'), 
	url(r'^gal','galeria.views.gal'), 
	url(r'^form_gal','galeria.views.form_gal'), 

	url(r'^lista_departamento','unidad.views.lista_departamento'),
	url(r'^info_departamento','unidad.views.info_departamento'),
	url(r'^agregar_departamento','unidad.views.agregar_departamento'), 
	url(r'^form_editar_departamento','unidad.views.form_editar_departamento'), 
	url(r'^borrar_departamento','unidad.views.borrar_departamento'), 

	url(r'^lista_plaza_departamento','unidad.views.lista_plaza_departamento'),
	url(r'^info_plaza_departamento','unidad.views.info_plaza_departamento'),
	url(r'^agregar_plaza_departamento','unidad.views.agregar_plaza_departamento'), 
	url(r'^form_editar_plaza_departamento','unidad.views.form_editar_plaza_departamento'), 
	url(r'^borrar_plaza_departamento','unidad.views.borrar_plaza_departamento'), 
 
	url(r'^lista_trabajador','rrhh.views.lista_trabajador'),
	url(r'^listatrabajadorsub','rrhh.views.listatrabajadorsub'),
	url(r'^info_trabajador','rrhh.views.info_trabajador'),
	url(r'^agregar_trabajador','rrhh.views.agregar_trabajador'), 
	url(r'^form_editar_trabajador','rrhh.views.form_editar_trabajador'), 
	url(r'^borrar_trabajador','rrhh.views.borrar_trabajador'),

	url(r'^tareas','tareas.views.tareas'), 
	url(r'^info_tarea','tareas.views.info_tareas'), 
	url(r'^agregar_tarea','tareas.views.agregar_tarea'), 
	url(r'^borrar_tarea','tareas.views.borrar_tarea'),
	url(r'^editar_tarea','tareas.views.editar_tarea'),
	url(r'^exportarcorta','tareas.views.exportarcorta'),
	url(r'^exportarlarga','tareas.views.exportarlarga'),
	url(r'^actividades','tareas.views.actividad'),
	url(r'^anual','tareas.views.anual'),









	url(r'^equipamiento','equipamiento.views.equipamiento'), 
	url(r'^tipoequipo','equipamiento.views.tipoequipo'),

#	url(r'^agregar_pc','equipamiento.views.agregar_pc'), 
	url(r'^agregar_teclado','equipamiento.views.registro_teclado'), 
	url(r'^agregar_raton','equipamiento.views.registro_raton'), 
	url(r'^agregar_ups','equipamiento.views.registro_ups'), 
	url(r'^agregar_switch','equipamiento.views.registro_switch'), 
	url(r'^agregar_ap','equipamiento.views.registro_ap'), 
	url(r'^agregar_camara','equipamiento.views.registro_camara'), 
	url(r'^agregar_impresora','equipamiento.views.registro_impresora'), 


	url(r'^info_pc','equipamiento.views.info_pc'), 
	url(r'^info_teclado','equipamiento.views.info_teclado'), 
	url(r'^info_raton','equipamiento.views.info_raton'), 
	url(r'^info_ups','equipamiento.views.info_ups'), 
	url(r'^info_switch','equipamiento.views.info_switch'), 
	url(r'^info_ap','equipamiento.views.info_ap'), 
	url(r'^info_camara','equipamiento.views.info_camara'), 
	url(r'^info_impresora','equipamiento.views.info_impresora'), 


	url(r'^borrar_pc','equipamiento.views.borrar_pc'), 
	url(r'^borrar_teclado','equipamiento.views.borrar_teclado'), 
	url(r'^borrar_raton','equipamiento.views.borrar_raton'), 
	url(r'^borrar_ups','equipamiento.views.borrar_ups'), 
	url(r'^borrar_switch','equipamiento.views.borrar_switch'), 
	url(r'^borrar_ap','equipamiento.views.borrar_ap'), 
	url(r'^borrar_camara','equipamiento.views.borrar_camara'), 
	url(r'^borrar_impresora','equipamiento.views.borrar_impresora'), 

	url(r'^editar_pc','equipamiento.views.editar_pc'), 
	url(r'^editar_teclado','equipamiento.views.editar_teclado'), 
	url(r'^editar_raton','equipamiento.views.editar_raton'), 
	url(r'^editar_ups','equipamiento.views.editar_ups'), 
	url(r'^editar_switch','equipamiento.views.editar_switch'), 
	url(r'^editar_ap','equipamiento.views.editar_ap'), 
	url(r'^editar_camara','equipamiento.views.editar_camara'), 
	url(r'^editar_impresora','equipamiento.views.editar_impresora'), 

	url(r'^listar_radio','radio.views.listar_radio'),

	url(r'^info_estacion_fija','radio.views.info_estacion_fija'), 
	url(r'^editar_estacion_fija','radio.views.editar_estacion_fija'), 
	url(r'^agregar_estacion_fija','radio.views.agregar_estacion_fija'),
	url(r'^borrar_estacion_fija','radio.views.borrar_estacion_fija'), 

	url(r'^info_estacion_movil','radio.views.info_estacion_movil'), 
	url(r'^editar_estacion_movil','radio.views.editar_estacion_movil'), 
	url(r'^agregar_estacion_movil','radio.views.agregar_estacion_movil'),
	url(r'^borrar_estacion_movil','radio.views.borrar_estacion_movil'), 

	url(r'^info_estacion_portatil','radio.views.info_estacion_portatil'), 
	url(r'^editar_estacion_portatil','radio.views.editar_estacion_portatil'), 
	url(r'^agregar_estacion_portatil','radio.views.agregar_estacion_portatil'),
	url(r'^borrar_estacion_portatil','radio.views.borrar_estacion_portatil'), 

	url(r'^info_estacion_repetidora','radio.views.info_estacion_repetidora'), 
	url(r'^editar_estacion_repetidora','radio.views.editar_estacion_repetidora'), 
	url(r'^agregar_estacion_repetidora','radio.views.agregar_estacion_repetidora'),
	url(r'^borrar_estacion_repetidora','radio.views.borrar_estacion_repetidora'), 

##############################
	 url(r'^listar_telefonia','telefonos.views.listar_telefonia'),

	 url(r'^info_pizarra','telefonos.views.info_pizarra'), 
	 url(r'^editar_pizarra','telefonos.views.editar_pizarra'), 
	 url(r'^agregar_pizarra','telefonos.views.agregar_pizarra'),
	 url(r'^borrar_pizarra','telefonos.views.borrar_pizarra'), 

	 url(r'^info_telefono','telefonos.views.info_telefono'), 
	 url(r'^editar_telefono','telefonos.views.editar_telefono'), 
	 url(r'^agregar_telefono','telefonos.views.agregar_telefono'),
	 url(r'^borrar_telefono','telefonos.views.borrar_telefono'), 

	 url(r'^info_extencion','telefonos.views.info_extencion'), 
	 url(r'^editar_extencion','telefonos.views.editar_extencion'), 
	 url(r'^agregar_extencion','telefonos.views.agregar_extencion'),
	 url(r'^borrar_extencion','telefonos.views.borrar_extencion'), 	 
###############################









 
	url(r'^contacto','mensajes.views.contacto'), 
	url(r'^logs','rrhh.views.mostrar_logs'), 

	url(r'^galeria','galeria.views.galeria'),

	#Aqui lo relacionado con los docuemntos de la unidad
	url(r'^form_editar_doc','carpeta.views.form_editar_doc'), 
	url(r'^documentos','carpeta.views.documentos'), 
	url(r'^docsubordinados','carpeta.views.docsubordinados'), 


	url(r'^form_documentos','carpeta.views.form_documentos'), 
	
	#Aqui lo relacionado con la conectividad de la unidad
	url(r'^conectividad','carpeta.views.conectividad'), 
	url(r'^formulario_editar_conectividad','carpeta.views.formulario_editar_conectividad'), 
	url(r'^formulario_web','carpeta.views.formulario_web'), 
	url(r'^formulario_enlace','carpeta.views.formulario_enlace'),
	url(r'^info_enlace','carpeta.views.info_enlace'),
	url(r'^info_web','carpeta.views.info_web'),
	url(r'^editar_enlace','carpeta.views.editar_enlace'),
	url(r'^editar_web','carpeta.views.editar_web'),
	url(r'^borrar_enlace','carpeta.views.borrar_enlace'),
	url(r'^borrar_web','carpeta.views.borrar_web'),
	
	url(r'^aplicaciones','carpeta.views.aplicaciones'),
	url(r'^form_aplicacion','carpeta.views.form_aplicacion'),
	url(r'^form_editar_app','carpeta.views.form_editar_app'),
	
	
	
	#Aqui lo relacionado con la Inspeccion de la unidad
	url(r'^editar_guia_inspeccion','inspeccion.views.editar_guia_inspeccion'),
	url(r'^editar_deficiencia','inspeccion.views.editar_deficiencia'),
	url(r'^inspeccion_unidades','inspeccion.views.inspeccion_unidades'),
	url(r'^guia_inspeccion','inspeccion.views.guia_inspeccion'),
	url(r'^info_visita','inspeccion.views.info_visita'),
	url(r'^deficiencias_unidad','inspeccion.views.deficiencias_unidad'),
	url(r'^ver_deficiencia','inspeccion.views.ver_deficiencia'),
	url(r'^deficiencia','inspeccion.views.deficiencia'),
	url(r'^exportar_inspeccion','inspeccion.views.exportar_inspeccion'),
	url(r'^visto_bueno','inspeccion.views.visto_bueno'),
	url(r'^erradicar_deficiencia','inspeccion.views.erradicar_deficiencia'),

	url(r'^unidad_enlace','reporte.views.unidad_enlace'),
	url(r'^reporte_unidad','reporte.views.reporte_unidad'),
	url(r'^listado','reporte.views.listado'),




	url(r'^reporte','rrhh.views.reporte'),




	url(r'^presupuesto','presupuesto.views.presupuesto'),
	url(r'^modificar_presupuesto','presupuesto.views.modificar_presupuesto'),
	
	url(r'^agregar_pc/$', ContactWizard.as_view([
	Formulario_pc, 
	Formulario_board_pc, 
	Formulario_procesador, 
	Formulario_ram, 
	Formulario_hdd, 
	Formulario_fuente, 
	Formulario_teclado,
	Formulario_raton,
	Formulario_monitor,
	Formulario_ups,
	Formulario_impresora
	])),



	url(r'^transporte/$','transporte.views.transporte'),
	url(r'^form_auto/$','transporte.views.form_auto'),
	url(r'^form_editar_auto/$','transporte.views.form_editar_auto'),
	url(r'^eliminar_auto','transporte.views.eliminar_auto'),
	url(r'^info_auto','transporte.views.info_auto'),
	
	url(r'^activos/$','activos.views.listaactivos'),
	url(r'^form_activos/$','activos.views.form_activo'),
	url(r'^form_editar_activos/$','activos.views.form_editar_activo'),
	url(r'^eliminar_activos','activos.views.eliminar_activo'),



	url(r'^info_centroscerrados','vigilancia.views.info_centroscerrados'),
	url(r'^agregar_centroscerrados','vigilancia.views.agregar_centroscerrados'),
	url(r'^borrar_centroscerrados','vigilancia.views.borrar_centroscerrados'),


	url(r'^info_centrospositivos','vigilancia.views.info_centrospositivos'),
	url(r'^agregar_centrospositivos','vigilancia.views.agregar_centrospositivos'),
	url(r'^borrar_centrospositivos','vigilancia.views.borrar_centrospositivos'),


	url(r'^info_recursos','vigilancia.views.info_recursos'),
	url(r'^agregar_recursos','vigilancia.views.agregar_recursos'),
	url(r'^borrar_recursos','vigilancia.views.borrar_recursos'),

	url(r'^info_tratamientoadulticida','vigilancia.views.info_tratamientoadulticida'),
	url(r'^agregar_tratamientoadulticida','vigilancia.views.agregar_tratamientoadulticida'),
	url(r'^borrar_tratamientoadulticida','vigilancia.views.borrar_tratamientoadulticida'),

	url(r'^info_tratamientofocal','vigilancia.views.info_tratamientofocal'),
	url(r'^agregar_tratamientofocal','vigilancia.views.agregar_tratamientofocal'),
	url(r'^borrar_tratamientofocal','vigilancia.views.borrar_tratamientofocal'),

	url(r'^info_albopictus','vigilancia.views.info_albopictus'),
	url(r'^agregar_albopictus','vigilancia.views.agregar_albopictus'),
	url(r'^borrar_albopictus','vigilancia.views.borrar_albopictus'),

	url(r'^info_centrospriorizados','vigilancia.views.info_centrospriorizados'),
	url(r'^agregar_centrospriorizados','vigilancia.views.agregar_centrospriorizados'),
	url(r'^borrar_centrospriorizados','vigilancia.views.borrar_centrospriorizados'),




    url(r'^listalavanderia','lavanderia.views.listar'),
    url(r'^reporlavanderia','lavanderia.views.agregar'),
    url(r'^elimilavanderia','lavanderia.views.eliminar'),


    url(r'^listaalimentos','alimentos.views.listar'),
    url(r'^reporalimentos','alimentos.views.agregar'),
    url(r'^elimialimentos','alimentos.views.eliminar'),





#~ 
	#~ url(r'^ascensor/$','singeniero.views.lista_ascensor'),
	#~ url(r'^eliminar_ascensor/$','singeniero.views.eliminar_ascensor'),
	#~ url(r'^form_ascensor/$','singeniero.views.form_ascensor'),
	#~ url(r'^editar_ascensor/$','singeniero.views.editar_ascensor'),
	#~ 
	#~ url(r'^calderas/$','singeniero.views.lista_calderas'),
	#~ url(r'^eliminar_calderas/$','singeniero.views.eliminar_calderas'),
	#~ url(r'^form_calderas/$','singeniero.views.form_calderas'),
	#~ url(r'^editar_calderas/$','singeniero.views.editar_calderas'),
	#~ 
	#~ url(r'^compresor/$','singeniero.views.lista_compresor'),
	#~ url(r'^eliminar_compresor/$','singeniero.views.eliminar_compresor'),
	#~ url(r'^form_compresor/$','singeniero.views.form_compresor'),
	#~ url(r'^editar_compresor/$','singeniero.views.editar_compresor'),
	#~ 
	#~ url(r'^bomba_agua_fria/$','singeniero.views.lista_bomba_agua_fria'),
	#~ url(r'^eliminar_bomba_agua_fria/$','singeniero.views.eliminar_bomba_agua_fria'),
	#~ url(r'^form_bomba_agua_fria/$','singeniero.views.form_bomba_agua_fria'),
	#~ url(r'^editar_bomba_agua_fria/$','singeniero.views.editar_bomba_agua_fria'),
	#~ 
	#~ url(r'^manejadoras/$','singeniero.views.lista_manejadoras'),
	#~ url(r'^eliminar_manejadoras/$','singeniero.views.eliminar_manejadoras'),
	#~ url(r'^form_manejadoras/$','singeniero.views.form_manejadoras'),
	#~ url(r'^editar_manejadoras/$','singeniero.views.editar_manejadoras'),
	#~ 
	#~ url(r'^extractores/$','singeniero.views.lista_extractores'),
	#~ url(r'^eliminar_extractores/$','singeniero.views.eliminar_extractores'),
	#~ url(r'^form_extractores/$','singeniero.views.form_extractores'),
	#~ url(r'^editar_extractores/$','singeniero.views.editar_extractores'),
	#~ 
	#~ url(r'^clima_expansion_directa/$','singeniero.views.lista_clima_expansion_directa'),
	#~ url(r'^eliminar_clima_expansion_directa/$','singeniero.views.eliminar_clima_expansion_directa'),
	#~ url(r'^form_clima_expansion_directa/$','singeniero.views.form_clima_expansion_directa'),
	#~ url(r'^editar_clima_expansion_directa/$','singeniero.views.editar_clima_expansion_directa'),
	#~ 
	#~ url(r'^bomba_agua/$','singeniero.views.lista_bomba_agua'),
	#~ url(r'^eliminar_bomba_agua/$','singeniero.views.eliminar_bomba_agua'),
	#~ url(r'^form_bomba_agua/$','singeniero.views.form_bomba_agua'),
	#~ url(r'^editar_bomba_agua/$','singeniero.views.editar_bomba_agua'),
	#~ 
	#~ url(r'^equipo_cocina/$','singeniero.views.lista_equipo_cocina'),
	#~ url(r'^eliminar_equipo_cocina/$','singeniero.views.eliminar_equipo_cocina'),
	#~ url(r'^form_equipo_cocina/$','singeniero.views.form_equipo_cocina'),
	#~ url(r'^editar_equipo_cocina/$','singeniero.views.editar_equipo_cocina'),
	#~ 
	#~ url(r'^equipo_lavanderia/$','singeniero.views.lista_equipo_lavanderia'),
	#~ url(r'^eliminar_equipo_lavanderia/$','singeniero.views.eliminar_equipo_lavanderia'),
	#~ url(r'^form_equipo_lavanderia/$','singeniero.views.form_equipo_lavanderia'),
	#~ url(r'^editar_equipo_lavanderia/$','singeniero.views.editar_equipo_lavanderia'),
	#~ 
	#~ url(r'^grupo_electrogeno/$','singeniero.views.lista_grupo_electrogeno'),
	#~ url(r'^eliminar_grupo_electrogeno/$','singeniero.views.eliminar_grupo_electrogeno'),
	#~ url(r'^form_grupo_electrogeno/$','singeniero.views.form_grupo_electrogeno'),
	#~ url(r'^editar_grupo_electrogeno/$','singeniero.views.editar_grupo_electrogeno'),
	#~ 
	#~ url(r'^campana_extraccion_gases/$','singeniero.views.lista_campana_extraccion_gases'),
	#~ url(r'^eliminar_campana_extraccion_gases/$','singeniero.views.eliminar_campana_extraccion_gases'),
	#~ url(r'^form_campana_extraccion_gases/$','singeniero.views.form_campana_extraccion_gases'),
	#~ url(r'^editar_campana_extraccion_gases/$','singeniero.views.editar_campana_extraccion_gases'),
	#~ 
	#~ url(r'^ventilador/$','singeniero.views.lista_ventilador'),
	#~ url(r'^eliminar_ventilador/$','singeniero.views.eliminar_ventilador'),
	#~ url(r'^form_ventilador/$','singeniero.views.form_ventilador'),
	#~ url(r'^editar_ventilador/$','singeniero.views.editar_ventilador'),
	#~ 
	#~ url(r'^panel_solar/$','singeniero.views.lista_panel_solar'),
	#~ url(r'^eliminar_panel_solar/$','singeniero.views.eliminar_panel_solar'),
	#~ url(r'^form_panel_solar/$','singeniero.views.form_panel_solar'),
	#~ url(r'^editar_panel_solar/$','singeniero.views.editar_panel_solar'),
#~ 

	url(r'^publicaciones/$','investigacion.views.lista_publicaciones'),
	url(r'^eliminar_publicaciones/$','investigacion.views.eliminar_publicaciones'),
	url(r'^form_publicaciones/$','investigacion.views.form_publicaciones'),
	url(r'^editar_publicaciones/$','investigacion.views.editar_publicaciones'),

#~ 
	url(r'^recluta/$','reclutamiento.views.lista_recluta'),
	url(r'^eliminar_recluta/$','reclutamiento.views.eliminar_recluta'),
	url(r'^form_recluta/$','reclutamiento.views.form_recluta'),
	url(r'^editar_recluta/$','reclutamiento.views.editar_recluta'),
	




	url(r'^infopedido','distribucion.views.infopedido'),
	url(r'^distribucion','distribucion.views.listar'),
	url(r'^repordistribucion','distribucion.views.agregar'),
	url(r'^elimidistribucion','distribucion.views.eliminar'),
	url(r'^editdistribucion','distribucion.views.editar'),



	)

